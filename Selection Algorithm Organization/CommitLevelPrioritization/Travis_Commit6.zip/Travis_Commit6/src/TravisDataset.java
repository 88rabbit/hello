import java.sql.SQLException;
import exeRecord.ExeRecord_Travis;
import parsingCommandLine.Cli;
import simulate.Simulation;

public class TravisDataset 
{
	public void getTravisDataset(String[] newString) throws ClassNotFoundException, SQLException
	{
		//setting the sql
	//	private static String sql = "SELECT TestSuite, ChangeRequest, Stage, Status_test, LaunchTime, ExecutionTime,size, Shared_number, Run_number, Language_test, T_number FROM AllData ORDER BY LaunchTime, T_number, Shared_number";
//		String sql = "SELECT * FROM AllData WHERE 
//		Cf_allow_failure = 0 AND Build_state != 'canceled' AND Build_state != 'errored' AND Ts_errors <= 0 ORDER BY Build_number, Ts_start_time, Ts_id";
//		String sql = "SELECT Ts_id, Ts_start_time, Ts_duration, Ts_runs, Ts_assertions, Ts_failures, Ts_errors, Ts_skips, Build_id, Commit_id, Build_number, Build_state, Build_start_time, Build_finish_time, Build_duration FROM AllData WHERE Cf_allow_failure = 0 AND Build_state != 'canceled' AND Build_state != 'errored'  ORDER BY Build_number, Ts_start_time, Ts_id";
		//most Recently used
//		String sql = "SELECT Ts_id, Ts_duration, Ts_runs, Ts_assertions, Ts_failures, Ts_errors, Ts_skips, Commit_sha, Build_number, Build_state, Build_start_time, Build_finish_time, Build_duration, Job_id, Job_state, Job_start_time,  Job_finish_time, Ts_order_in_job, Job_allow_failure FROM AllData WHERE !(Ts_errors > 0 AND Ts_failures = 0) ORDER BY Build_number, Job_id, Job_start_time";
//		String sql = "SELECT Ts_id, Ts_duration, Ts_runs, Ts_assertions, Ts_failures, Ts_errors, Ts_skips, Commit_sha, Build_number, Build_state, Build_start_time, Build_finish_time, Build_duration, Job_id, Job_start_time, Job_finish_time,a Ts_order_in_job, Job_allow_failure FROM AllData WHERE !(Ts_errors > 0 AND Ts_failures = 0) ORDER BY Build_start_time, Build_number, Job_start_time, Job_id";
//		
		/*
		 * Most recently used
		 */
		//String sql = "SELECT Ts_id, Ts_duration, Ts_runs, Ts_assertions, Ts_failures, Ts_errors, Ts_skips, Commit_sha, Build_number, Build_state, Build_start_time, Build_finish_time, Build_duration, Job_id, Job_state, Job_start_time,  Job_finish_time, Ts_order_in_job, Job_allow_failure FROM AllData ORDER BY Build_number, Job_id, Job_start_time";
		
		/*
		 * For new Simplifiled
		 */
		String sql = "SELECT Ts_id, Ts_duration, Ts_runs, Ts_assertions, Ts_failures, Ts_errors, Ts_skips, Commit_sha, Build_number, Build_state, Build_start_time, Build_finish_time, Build_duration, Job_id, Job_state, Job_start_time,  Job_finish_time, Ts_order_in_job, Job_allow_failure, Ts_start_time FROM AllData ORDER BY Build_number, Job_id, Job_start_time";
//		String sql = "SELECT Ts_id, Ts_duration, Ts_runs, Ts_assertions, Ts_failures, Ts_errors, Ts_skips, Commit_sha, Build_number, Build_state, Build_start_time, Build_finish_time, Build_duration,  Ts_start_time FROM AllData ORDER BY Ts_start_Time";
//		String sql = "select * from AllData order by Ts_start_Time";
//		String sql = "SELECT a.* FROM AllData AS a INNER JOIN crPercent as cr on a.Build_number = cr.Build_number WHERE a.Cf_allow_failure = 0 AND a.Build_state != 'canceled' AND a.Build_state != 'errored' ORDER BY cr.percent DESC, a.Ts_start_time, a.Ts_id";
		
				
		int distinctTsNum = 2073;
		
		int failWindow=Integer.parseInt(newString[1]);
		int executionWindow=Integer.parseInt(newString[2]);
		
		// setting the followings, Strings should be "minutes" or "hours"
		String failmmhh= newString[3];
		String executemmhh = newString[4];	
		
		int repetiveWindow = Integer.parseInt(newString[5]);
		String repetivemmhh = newString[6];
		
		String alwaysExecutedStage = newString[7];
		String selectedStage = newString[8];
		
		
		int coeff_f = Integer.parseInt(newString[9]);
		int coeff_e = Integer.parseInt(newString[10]);
		double rate = Double.parseDouble(newString[11]);
		int numOfProcessor = Integer.parseInt(newString[12]);
		boolean isIntra = Boolean.parseBoolean(newString[13]);
		
		
//		int failWindow= 24;
//		int executionWindow=24;
//		
//		// setting the followings, Strings should be "minutes" or "hours"
//		String failmmhh= "hours";
//		String executemmhh = "hours";
		
		// setting the phase of testSuites		
		
		Simulation simulation = new Simulation();
		ExeRecord_Travis exeRec = new ExeRecord_Travis();
		exeRec.initializeRecord(distinctTsNum);
		
		simulation.simulate_Travis(sql, failWindow, executionWindow, failmmhh, executemmhh, distinctTsNum, repetiveWindow, repetivemmhh, coeff_f, coeff_e, rate, numOfProcessor, exeRec, isIntra);
		
	
	}
}
