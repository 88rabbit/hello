package simulate;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.TreeMap;

import databaseInfo.DatabaseInformation;
import exeRecord.ExeRecord_Travis;
import executeTS.ExecuteTestSuites_Travis;
//import readFile.ReadAllRecords;

public class Simulation 
{	
	public void simulate_Travis(String sql, int failWindow,int executionWindow, String failmmhh,String executemmhh, int distinctTsNum, int repetiveWindow, String repetivemmhh, 
			int coeff_f, int coeff_e, double rate, int numOfProcessor, ExeRecord_Travis exeRec, boolean isIntra) throws ClassNotFoundException, SQLException
	{	
//		String url = "jdbc:mysql://localhost:3306/Travis_CI";
//		String url = "jdbc:mysql://localhost:3306/test_Travis";
//		String url = "jdbc:mysql://localhost:3306/Travis_configued";
//		String url = "jdbc:mysql://localhost:3306/railsRails";
//		String url = "jdbc:mysql://localhost:3306/railRails_dupVersion";
		String url = "jdbc:mysql://localhost:3306/rails_simplyfiedWithTime";
		String username = "root";
		String password = "";
//		
////		//connect database
		DatabaseInformation dbInfo = new DatabaseInformation();
		ResultSet rs = dbInfo.connectDatabase(sql,url, username, password);
//
//		System.out.println("?????");
		//execute TestSuites
		ExecuteTestSuites_Travis executeTs = new ExecuteTestSuites_Travis(exeRec, numOfProcessor, rate, isIntra);
		executeTs.executeTestSuites(rs, failWindow, executionWindow,failmmhh,executemmhh, distinctTsNum, repetiveWindow, repetivemmhh, coeff_f, coeff_e, rate, numOfProcessor);
//				
//		
		
//		//counting numbers of testsuites
//				double all_TSnumber = executeTs.getAll_TSnumber();
//				double all_failNumber=executeTs.getAll_failNumber();
//				double all_ExeTime_Travis = executeTs.getAll_ExeTime_Travis();
//				
//				double executed_TSnumber = executeTs.getExecuted_TSnumber();
//				double executed_failNumber = executeTs.getExecuted_failNumber();
//				double executed_ExeTime_Travis = executeTs.getExecuted_ExeTime_Travis();
//				
//				System.out.println("Number of allTestSuites: "+all_TSnumber);
//				System.out.println("Number of executedTests: "+executed_TSnumber);
//				System.out.println("allExeTime: "+all_ExeTime_Travis);
//				System.out.println("executedTSTime: "+executed_ExeTime_Travis);
//				System.out.println("allFailTests: "+ all_failNumber);
//				System.out.println("failTests: "+ executed_failNumber);
////				System.out.println("all detected: " + executeTs.getSimulateCommitExe().getTotalNumOfCommits());
//				System.out.println("fail commits detected: " + executeTs.getSimulateCommitExe().getDetectedFailCommits());
//				System.out.println();
//		
//		
//		//counting numbers of testsuites
//				
//				
//				
////				System.out.println(apfdCommits);
//				double totalCommitsTime = (double)executeTs.getTotalTimeLine()/(double)(1000*60*60);
////				double totalCommitsTime = (double)18178496377.00/(double)(1000*60*60);
//////				if(selectedStage.equals("pres"))
////					totalCommitsTime = (double)1906241540.00/(double)(1000*60*60);
////				else 
////					totalCommitsTime = (double)4192794408.00/(double)(1000*60*60);
//				
////				double totalTsExeTime = executed_ExeTime/(double)(1000*60*60);
//				double allFailTestNum = executed_failNumber;
//				
////					
////				
////				
//				double ftotalTestTime = executeTs.getSimulateCommitExe().getAccumulateExe().getFtotal_exeTime();
////				double allFailCommitsNum = (double)executeTs.getSimulateCommitExe().getDetectedFailCommits();
//				System.out.println("ftotalTestTime: " + ftotalTestTime);
////				System.out.println("totalCommitsTime:" + totalTsExeTime);
////				apfdCommits =  1-(totalCommitsTime/(double)(allFailCommits*totalCommitsTime)) + 1/(double)(2*totalCommitsTime);
//				double apfdTestCost =  1-(ftotalTestTime/(double)(allFailTestNum*totalCommitsTime)) + 1/(double)(2*totalCommitsTime);
//				System.out.println("Tests Time based apfd: "+ apfdTestCost);
////				System.out.println(apfdCommitsCost);
//				System.out.println();
//				
//				
//				
//				
//				
//				
//				/*
//				 * time commits apfd
//				 */
//////				double 
////				double totalCommitsTime = 0;
////				if(selectedStage.equals("pres"))
////					totalCommitsTime = (double)1906241540.00/(double)(1000*60*60);
////				else 
////					totalCommitsTime = (double)2218688377.00/(double)(1000*60*60);
////					
////				double totalCommitsTime = (double)executeTs.getTotalTimeLine()/(double)(1000*60*60);
////				
//				double ftotalCommitTime = executeTs.getSimulateCommitExe().getfApfd();
//				double allFailCommitsNum = (double)executeTs.getSimulateCommitExe().getDetectedFailCommits();
//				System.out.println("ftotalCommitTime: " + ftotalCommitTime);
//				System.out.println("totalCommitsTime:" + totalCommitsTime);
////				apfdCommits =  1-(totalCommitsTime/(double)(allFailCommits*totalCommitsTime)) + 1/(double)(2*totalCommitsTime);
//				double apfdCommitsCost =  1-(ftotalCommitTime/(double)(allFailCommitsNum*totalCommitsTime)) + 1/(double)(2*totalCommitsTime);
//				System.out.println("Commit Time based apfd: "+ apfdCommitsCost);
////				System.out.println(apfdCommitsCost);
//				System.out.println();
//				
//				System.out.println("ftotalCommitTime: " + (double)(ftotalCommitTime*60*60));
//				System.out.println("totalCommitsTime:" + (double)(totalCommitsTime*60*60));
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//				//counting numbers of testsuites
////				double all_TSnumber = executeTs.getAll_TSnumber();
////				double all_failNumber=executeTs.getAll_failNumber();
////				double all_ExeTime_Travis = executeTs.getAll_ExeTime_Travis();
////				
////				double executed_TSnumber = executeTs.getExecuted_TSnumber();
////				double executed_failNumber = executeTs.getExecuted_failNumber();
////				double executed_ExeTime_Travis = executeTs.getExecuted_ExeTime_Travis();
////				
////				System.out.println("Number of allTestSuites: "+all_TSnumber);
////				System.out.println("Number of executedTests: "+executed_TSnumber);
////				System.out.println("allExeTime: "+all_ExeTime_Travis);
////				System.out.println("executedTSTime: "+executed_ExeTime_Travis);
////				System.out.println("allFailTests: "+ all_failNumber);
////				System.out.println("failTests: "+ executed_failNumber);
////				System.out.println();
////				
////				double percentOfSelectedTS = executed_TSnumber/all_TSnumber;
////				System.out.println("Percentage of test suites selected is: "+percentOfSelectedTS*100);
////				double percentOfExeTime = executed_ExeTime_Travis/all_ExeTime_Travis;
////				System.out.println("Percentage of execution time is: "+ percentOfExeTime*100);
////				double percentOfFailDetected = executed_failNumber/all_failNumber;
////				System.out.println("Percentage of failure detected is: " + percentOfFailDetected*100);
////				System.out.println();
////				System.out.println(percentOfSelectedTS*100);
////				System.out.println(percentOfExeTime*100);
////				System.out.println(percentOfFailDetected*100);
////				
//////				System.out.println(executeTs.getExeRec().countDistinctFails());
//////				System.out.println();
////				
////				System.out.println("Total commits: "+ executeTs.getCombineCommits().getNumOfCommit());
////				
////				System.out.println("Executed commits: "+ executeTs.getCombineCommits().getExeNumOfCommit());
////				
////				System.out.println("% of executed commits: "+ 100*executeTs.getCombineCommits().getExeNumOfCommit()/executeTs.getCombineCommits().getNumOfCommit());
////				
////				System.out.println("Total failCommits: "+executeTs.getCombineCommits().getFailCommits());
////				
////				System.out.println("Detected failCommits: "+executeTs.getCombineCommits().getDetectedFailCommits());
////				
//////				System.out.println("Total failBuilds: "+ executeTs.getCombineCommits().getFailBuilds());
////				
//////				System.out.println("number of commits that contains stars: " + executeTs.getCombineCommits().getCommitsStar());
//////				System.out.println("number of stars: " + executeTs.getCombineCommits().getStars());
////				
////				double ftoal = executeTs.getFtotal();
////				double apfd = 1-(ftoal/(double)(all_failNumber*all_TSnumber)) + 1/(double)(2*all_TSnumber);
////				System.out.println("Ts count based apfd: " + apfd);
////				
//////				System.out.println();
//////				Map<Integer, Double> map =new TreeMap<Integer, Double>(executeTs.getMap());
//////							
//////				for(Integer i: map.keySet())
//////				{
//////					System.out.println(i + ","+ map.get(i));
//////				}
////				
////				
//////				double ftotalCommit = executeTs.getCombineCommits().getCommitFailApfd();
//////				double allFailCommits = (double)executeTs.getCombineCommits().getFailCommits();
//////				double totalCommits = (double)executeTs.getCombineCommits().getNumOfCommit();
//////				System.out.println(ftotalCommit);
//////				double apfdCommits =  1-(ftotalCommit/(double)(allFailCommits*totalCommits)) + 1/(double)(2*totalCommits);
//////				System.out.println("Commit count based apfd: "+ apfdCommits);
////				
////				
////				double ftotalCommit = executeTs.getCombineCommits().getCommitFailApfd();
////				double allFailCommits = (double)executeTs.getCombineCommits().getDetectedFailCommits();
////				double totalCommits = (double)executeTs.getCombineCommits().getExeNumOfCommit();
////				System.out.println(ftotalCommit);
////				double apfdCommits =  1-(ftotalCommit/(double)(allFailCommits*totalCommits)) + 1/(double)(2*totalCommits);
////				System.out.println("Commit count based apfd: "+ apfdCommits);
////				
////				System.out.println();		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
//		
////		double numOfExeWithFail=0;
////		for(int i=1; i<distinctTsNum; i++)
////		{
////			if(executeTs.getExeRec().getIsFail_Ts()[i])
////			{
//////			 System.out.println(executeTs.getExeRec().getTs_failureNum()[i]);
////			 numOfExeWithFail = numOfExeWithFail + executeTs.getExeRec().getNumOfExe()[i];
////			}
////		}
////		System.out.println((double)(numOfExeWithFail/all_TSnumber)*100);
////		System.out.println((double)(executeTs.getExeRec().getExeAfterFail()/all_TSnumber)*100);
////		System.out.println((double)(numOfExeWithFail/executed_TSnumber)*100);
////		System.out.println((double)(executeTs.getExeRec().getExeAfterFail()/executed_TSnumber)*100);
////		
////		
////		
////		
////		
////		
//////		System.out.println(executeTs.getSelectTests().getNew_Pass());
//////		System.out.println(executeTs.getSelectTests().getNew_Fail());
//////		System.out.println(executeTs.getSelectTests().getPass_Pass());
//////		System.out.println(executeTs.getSelectTests().getPass_Fail());
//////		System.out.println(executeTs.getSelectTests().getFail_Pass());
//////		System.out.println(executeTs.getSelectTests().getFail_Fail());
//		
		
		
	}
	
	
	
//	
	
	
}
