package executeTS;


import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

import exeRecord.ExeRecord_Travis;
import testSuites.TestSuite_Travis;


public class Commit 
{
	private int commitId;
	private List<TestSuite_Travis> allTests;
	private boolean isFailCommit;
	private int isFailBuild;
	private double duration; // millisecond --> duration of the whole commit
	
//	private boolean isFail;
	
	private List<TestSuite_Travis> rest;
	
	private double totalExeTime;
	private int failNumber;
	private int totalNum;
	
//	private int countNumber;
//	private double countTsDuration;
	
	private List<TestSuite_Travis> fail;
	private List<TestSuite_Travis> notFail;
	
//	private int starTs =0;
//	private boolean containStars;
	
//	private PriorityQueue<TestSuite_Travis> pqTests;
	
	
	private int numTsSatisfy_fail;
	private int numTsSatisfy_exe;
	
//	private CountFailures cf;
	private boolean checkFail;
//	private int commitNum;
	double failRatio = 0; // possible fail
	double exeRatio = 0; // possible fail
//	double ratio_fail = 0; // fail ratio
	
	private Timestamp buildStartTime;
	private Timestamp buildEndTime;
	
//	private Timestamp firstJobStartTime;
//	private double buildingTime;
	
//	private Timestamp jobEndTime;

		
//	private boolean isEarliest;
//	private TestSuite_Travis lastTest;
//	private Timestamp exeEndTime;
	
	
	private Timestamp commitArrivalTime; // calculate the arrival time of the commit
//	private Timestamp commitShiftEndTime;
	private Calendar calForFail;
	private Calendar tempEnd;
	
//	private boolean[] isFirstFailTest;	
	private int[] eachTestFailTimes;
//	private boolean distinctFails[];
	
	private double jobExeTime;
//	private long commitEnterQueueTime; 
	private double commitEnterQueueTime; 
	
	private Map<Integer, Double[]> jobMap = new HashMap<Integer, Double[]>();
	
	public void init(TestSuite_Travis ts, int[] eachTestFailTimes)
	{
		this.commitId = ts.getBuild_number();
		this.isFailCommit = ts.getBuild_state().equals("failed")? true:false;
		this.isFailBuild = ts.getBuild_state().equals("failed")? 1:0;
		this.duration = ts.getBuild_finish_time().getTime() - ts.getBuild_start_time().getTime(); // commit whole time
		
		this.allTests = new ArrayList<TestSuite_Travis>();
		this.rest = new ArrayList<TestSuite_Travis>();
		this.fail = new ArrayList<TestSuite_Travis>();
		this.notFail = new ArrayList<TestSuite_Travis>();
		
		this.totalExeTime = 0;
		this.failNumber = 0;
		this.totalNum = 0;
		
		this.numTsSatisfy_fail = 0;
		this.numTsSatisfy_exe = 0;
		this.checkFail = false;
		this.buildStartTime = ts.getBuild_start_time();
		this.buildEndTime = ts.getBuild_finish_time();
		
//		this.firstJobStartTime = ts.getJob_start_time();
//		this.buildingTime = firstJobStartTime.getTime() - buildStartTime.getTime();
//		System.out.println(buildStartTime + ","+ firstJobStartTime);
//		this.jobEndTime = ts.getJob_finish_time();
		
		
//		System.out.println(duration + ":" + buildStartTime + " - "+ buildEndTime );
		
//		this.isEarliest = true;
		this.calForFail = Calendar.getInstance();
		this.tempEnd = Calendar.getInstance();
		this.commitArrivalTime = ts.getBuild_start_time();
		
//		this.distinctFails = new boolean[2073];
//		for(int i=0; i<2073; i++)
//			distinctFails[i] = true;
		
		
//		this.isFirstFailTest = new boolean[2073];
//		for(int i=0; i<2073; i++)
//			isFirstFailTest[i] = true;
//		this.eachTestFailTimes = eachTestFailTimes;
			
	}
	
	public void init(TestSuite_Travis ts)
	{
		this.commitId = ts.getBuild_number();
		this.isFailCommit = ts.getBuild_state().equals("failed")? true:false;
		this.isFailBuild = ts.getBuild_state().equals("failed")? 1:0;
		this.duration = ts.getBuild_finish_time().getTime() - ts.getBuild_start_time().getTime();
		
		this.allTests = new ArrayList<TestSuite_Travis>();
		this.rest = new ArrayList<TestSuite_Travis>();
		this.fail = new ArrayList<TestSuite_Travis>();
		this.notFail = new ArrayList<TestSuite_Travis>();
		
		this.totalExeTime = 0;
		this.failNumber = 0;
		this.totalNum = 0;
		
		this.numTsSatisfy_fail = 0;
		this.numTsSatisfy_exe = 0;
		this.checkFail = false;
		this.buildStartTime = ts.getBuild_start_time();
		this.buildEndTime = ts.getBuild_finish_time();
//		System.out.println(duration + ":" + buildStartTime + " - "+ buildEndTime );
		
//		this.isEarliest = true;
		this.calForFail = Calendar.getInstance();
		this.tempEnd = Calendar.getInstance();
		this.commitArrivalTime = ts.getBuild_start_time();
		
//		this.distinctFails = new boolean[2073];
//		for(int i=0; i<2073; i++)
//			distinctFails[i] = true;
		
		this.eachTestFailTimes = eachTestFailTimes;
	
			
	}
	
	
	public void storeTestsInCommit(TestSuite_Travis ts)
	{
		// to record the start and end time of the commit
//		if(isEarliest)
//		{
//			exeStartTime = ts.getTs_start_time();
//			isEarliest = false;
//		}
//		lastTest = ts; // update the last
		
//		if(this.jobEndTime.before(ts.getJob_finish_time()))
//			this.jobEndTime = ts.getJob_finish_time();
		
		
		if(jobMap.containsKey(ts.getJob_id()))
		{
			jobExeTime += ts.getTs_duration();
			Double[] temp = jobMap.get(ts.getJob_id());
			temp[1] = jobExeTime;
			jobMap.put(ts.getJob_id(), temp);
		}
		else
		{
			Double[] time = new Double[2];
			time[0] = (double)(ts.getJob_finish_time().getTime()- ts.getJob_start_time().getTime());
			time[1] = ts.getTs_duration();
			jobMap.put(ts.getJob_id(), time);
			jobExeTime = 0;
		}
		
//		System.out.println(ts.getTs_duration());
//		System.out.println(jobExeTime);
		
		allTests.add(ts);
		totalNum ++;
		totalExeTime += ts.getTs_duration();
		if(ts.isFail_Ts())
		{
			checkFail = true;
			failNumber ++;
			fail.add(ts);
//			System.out.println(ts.getTsId());
//			if(isFirstFailTest[ts.getTsId()])
//			{
//				isFirstFailTest[ts.getTsId()] = false;
//				this.eachTestFailTimes[ts.getTsId()] ++;
//			}
			
		}
	}
	
	
	public void update(TestSuite_Travis ts, ExeRecord_Travis exeRec, int deltaFail, int deltaExe, int exeNumOfCommit)
	{
//		if(isEarliest)
//		{
////			exeStartTime = ts.getTs_start_time();
//			isEarliest = false;
//		}		
//		lastTest = ts; // update the last
//			
		
		allTests.add(ts);
		totalNum ++;
		
		totalExeTime += ts.getTs_duration();
		
		if(ts.isFail_Ts())
		{
			checkFail = true;
			failNumber ++;
		}
//		System.out.println(deltaFail + ":" + deltaExe);	
			//1. for new tests
		if(exeRec.getIsExecuted()[ts.getTsId()] == false)
		{	
			numTsSatisfy_exe++;	
		}
		//for execution selection
		else 
		{
			if(exeNumOfCommit - exeRec.getCommitsSinceLastExe()[ts.getTsId()]-1 >= deltaExe )
			{
				numTsSatisfy_exe++;
			}
			
			if (exeRec.getIsFail_Ts()[ts.getTsId()] && exeNumOfCommit - exeRec.getCommitsSinceLastFail()[ts.getTsId()] - 1<= deltaFail)
//			if (exeRec.getTimesSinceLastFail()[ts.getTsId()]>=0 )
			{		
				
				numTsSatisfy_fail ++;	
//				System.out.println(commitId +":" + numTsSatisfy_fail);
			}
		}	
//				notFail.add(ts);
			
				
	
	}
	
	public void updateProcessCommit(Accumulation accumulateExe, ExeRecord_Travis exeRec, UpdateExeRecord updateExeRecords, int exeNumOfCommit, double timePassed)
	{
		
		for(TestSuite_Travis ts: allTests)
		{	
			
			updateExeRecords.updateDetails_Travis(exeRec, ts, accumulateExe, true, exeNumOfCommit, timePassed);
			
			if(ts.isFail_Ts())
			{
				checkFail = true;
				fail.add(ts);
			}
		}
		
		
	}
	
	public void updateProcessCommit_Intra(Accumulation accumulateExe, ExeRecord_Travis exeRec, UpdateExeRecord updateExeRecords, int exeNumOfCommit, double timePassed,  int deltaFail, int deltaExe)
	{
		List<TestSuite_Travis> lowerPriority = new ArrayList<TestSuite_Travis>();
		List<TestSuite_Travis> higherPriority = new ArrayList<TestSuite_Travis>();
		
		for(TestSuite_Travis ts: allTests)
		{	
			//1. for new tests
			if(exeRec.getIsExecuted()[ts.getTsId()] == false)
			{
				higherPriority.add(ts);
			}
			else if((exeNumOfCommit - exeRec.getCommitsSinceLastExe()[ts.getTsId()]-1 >= deltaExe) 
					||(exeRec.getIsFail_Ts()[ts.getTsId()] && exeNumOfCommit - exeRec.getCommitsSinceLastFail()[ts.getTsId()] - 1<= deltaFail))
			{
				higherPriority.add(ts);
			}
			else
			{
				lowerPriority.add(ts);
			}			
		}
		
		for(TestSuite_Travis ts: higherPriority)
		{
			updateExeRecords.updateDetails_Travis(exeRec, ts, accumulateExe, true, exeNumOfCommit, timePassed);
			if(ts.isFail_Ts())
			{
				checkFail = true;
			}
		}
		
		for(TestSuite_Travis ts: lowerPriority)
		{
			updateExeRecords.updateDetails_Travis(exeRec, ts, accumulateExe, true, exeNumOfCommit, timePassed);
			if(ts.isFail_Ts())
			{
				checkFail = true;
			}
		}
	}
	
	
	
//	private Timestamp maxEnd;
//	private Timestamp curEnd;
//	
//	private Calendar resetStartTime =  Calendar.getInstance();
//	private double gap;
//	
//	public void calculateDuration()
//	{
//		exeEndTime = lastTest.getTs_start_time();
////		System.out.println(commitId + ": "+ allTests.size() + ":"+ lastTest.getTs_start_time());
//		calForFail.setTime(new Date(lastTest.getTs_start_time().getTime()));	// set the last test of the commit's time		
//		calForFail.add(Calendar.MILLISECOND, (int)lastTest.getTs_duration());
//		this.exeEndTime =  new Timestamp(calForFail.getTime().getTime());
//		
////		System.out.println(exeStartTime + "; "+lastTest.getLast_launchTime() + ","+lastTest.getLast_executionTime() + this.exeEndTime);		
//		this.duration = this.exeEndTime.getTime() - this.exeStartTime.getTime(); // total duration
//		
//	
//		// get the gap
//		calForFail.setTime(new Date(allTests.get(0).getTs_start_time().getTime()));	// set the first test of the commit's time
//		calForFail.add(Calendar.MILLISECOND, (int)allTests.get(0).getTs_duration());		
//		this.maxEnd = new Timestamp(calForFail.getTime().getTime());
//		
//		boolean reset = false;
//		for(TestSuite_Travis ts: allTests)
//		{			
////			if(id == 330)
////				System.out.println(ts.getLast_launchTime());
////			
//			tempEnd.setTime(new Date(ts.getTs_start_time().getTime()));
//			tempEnd.add(Calendar.MILLISECOND, (int)ts.getTs_duration());
//			this.curEnd = new Timestamp(tempEnd.getTime().getTime());
//			
//			if(this.maxEnd.before(ts.getTs_start_time()))
//			{
//				gap += ts.getTs_start_time().getTime() - this.maxEnd.getTime();
//				reset = true;
//			}
//			
//			// reset the original Test suites' launch time
//			if(reset)
//			{			
//				resetStartTime.setTime(new Date(ts.getTs_start_time().getTime()));
//				resetStartTime.add(Calendar.MILLISECOND, -(int)gap);
//				ts.setTs_start_time(new Timestamp(resetStartTime.getTime().getTime()));  
//			
//			}
//			
//			if(this.maxEnd.before(this.curEnd))
//				this.maxEnd = this.curEnd;						
//		}
//		
//		this.duration = this.maxEnd.getTime() - this.exeStartTime.getTime() - gap;
//		
//	}
		
	/*
	 * commit_arrival = C_lauchtime - Avg(Commit duration) )
	 */
//	private Calendar calForFailArrive;	
//	
//	public Timestamp commitArrivalTime() 
//	{
//		this.calForFailArrive = Calendar.getInstance();
////		double day=0;
//		calForFailArrive.setTime(new Date(exeStartTime.getTime())); // use original exe time as arrival time
//		this.commitArrivalTime =  new Timestamp(calForFailArrive.getTime().getTime());
//		return this.commitArrivalTime;
//	}
	
//	public Timestamp commitShiftEndTime()
//	{
//		calForFailEnd.setTime(new Date(commitArrivalTime.getTime()));
//		calForFailEnd.add(Calendar.MILLISECOND, (int)duration);
//		
//		Timestamp commitShiftEndTime = new Timestamp(calForFailEnd.getTime().getTime());
//		return commitShiftEndTime;
//	}
	
	
	
	public double getExeRatio() 
	{
		this.exeRatio = (double)numTsSatisfy_exe/(double)totalNum;
		
		return exeRatio;
		
//		return numTsSatisfy_exe;
	}

//	public double getRatio_fail() 
//	{
//		this.ratio_fail = (double)failNumber/(double)totalNum;
//		return ratio_fail;
//	}
	
	public double getFailRatio() 
	{
		this.failRatio = (double)numTsSatisfy_fail/(double)totalNum;
		
		return failRatio;
		
//		return numTsSatisfy_fail;
	}

	public int getCommitId() {
		return commitId;
	}

	public void setCommitId(int commitId) {
		this.commitId = commitId;
	}

	public List<TestSuite_Travis> getAllTests() {
		return allTests;
	}

	public void setAllTests(List<TestSuite_Travis> allTests) {
		this.allTests = allTests;
	}

	public int getIsFailBuild() {
		return isFailBuild;
	}

	public void setIsFailBuild(int isFailBuild) {
		this.isFailBuild = isFailBuild;
	}

//	public boolean isFail() {
//		return isFail;
//	}
//
//	public void setFail(boolean isFail) {
//		this.isFail = isFail;
//	}

//	public int getStarTs() {
//		return starTs;
//	}
//
//	public void setStarTs(int starTs) {
//		this.starTs = starTs;
//	}
//
//	public boolean isContainStars() {
//		return containStars;
//	}
//
//	public void setContainStars(boolean containStars) {
//		this.containStars = containStars;
//	}

	public List<TestSuite_Travis> getRest() {
		return rest;
	}

	public void setRest(List<TestSuite_Travis> rest) {
		this.rest = rest;
	}

	public double getTotalExeTime() {
		return totalExeTime;
	}

	public void setTotalExeTime(double totalExeTime) {
		this.totalExeTime = totalExeTime;
	}

	public int getFailNumber() {
		return failNumber;
	}

	public void setFailNumber(int failNumber) {
		this.failNumber = failNumber;
	}

//	public int getCountNumber() {
//		return countNumber;
//	}
//
//	public void setCountNumber(int countNumber) {
//		this.countNumber = countNumber;
//	}
//
//	public double getCountTsDuration() {
//		return countTsDuration;
//	}
//
//	public void setCountTsDuration(double countTsDuration) {
//		this.countTsDuration = countTsDuration;
//	}

	public List<TestSuite_Travis> getFail() {
		return fail;
	}

	public void setFail(List<TestSuite_Travis> fail) {
		this.fail = fail;
	}

//	public PriorityQueue<TestSuite_Travis> getPqTests() {
//		return pqTests;
//	}
//
//	public void setPqTests(PriorityQueue<TestSuite_Travis> pqTests) {
//		this.pqTests = pqTests;
//	}

	public List<TestSuite_Travis> getNotFail() {
		return notFail;
	}

	public void setNotFail(List<TestSuite_Travis> notFail) {
		this.notFail = notFail;
	}

	public int getNumTsSatisfy_fail() {
		return numTsSatisfy_fail;
	}

	public void setNumTsSatisfy_fail(int numTsSatisfy_fail) {
		this.numTsSatisfy_fail = numTsSatisfy_fail;
	}

	public int getNumTsSatisfy_exe() {
		return numTsSatisfy_exe;
	}

	public void setNumTsSatisfy_exe(int numTsSatisfy_exe) {
		this.numTsSatisfy_exe = numTsSatisfy_exe;
	}

	public int getTotalNum() {
		return totalNum;
	}

	public void setTotalNum(int totalNum) {
		this.totalNum = totalNum;
	}


	public boolean isCheckFail() {
		return checkFail;
	}

	public void setCheckFail(boolean checkFail) {
		this.checkFail = checkFail;
	}


	public Timestamp getBuildStartTime() {
		return buildStartTime;
	}


	public void setBuildStartTime(Timestamp buildStartTime) {
		this.buildStartTime = buildStartTime;
	}


	public Timestamp getBuildEndTime() {
		return buildEndTime;
	}


	public void setBuildEndTime(Timestamp buildEndTime) {
		this.buildEndTime = buildEndTime;
	}
	public double getDuration() {
//		return totalExeTime;
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}
	
	public Timestamp getCommitArrivalTime() {
		return commitArrivalTime;
	}

	public void setCommitArrivalTime(Timestamp commitArrivalTime) {
		this.commitArrivalTime = commitArrivalTime;
	}


	public boolean isFailCommit() {
		return isFailCommit;
	}


	public void setFailCommit(boolean isFailCommit) {
		this.isFailCommit = isFailCommit;
	}

	public Map<Integer, Double[]> getJobMap() {
		return jobMap;
	}

	public void setJobMap(Map<Integer, Double[]> jobMap) {
		this.jobMap = jobMap;
	}

	public double getCommitEnterQueueTime() {
		return commitEnterQueueTime;
	}

	public void setCommitEnterQueueTime(double commitEnterQueueTime) {
		this.commitEnterQueueTime = commitEnterQueueTime;
	}

//	public long getCommitEnterQueueTime() {
//		return commitEnterQueueTime;
//	}
//
//	public void setCommitEnterQueueTime(long commitEnterQueueTime) {
//		this.commitEnterQueueTime = commitEnterQueueTime;
//	}

	
//	
}
