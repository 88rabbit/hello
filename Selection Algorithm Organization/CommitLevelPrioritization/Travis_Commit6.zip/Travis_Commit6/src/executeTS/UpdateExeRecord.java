package executeTS;


import testSuites.TestSuite_Google;
import testSuites.TestSuite_Travis;
import exeRecord.ExeRecord_Google;
import exeRecord.ExeRecord_Travis;

public class UpdateExeRecord 
{
	private Accumulation accumulateExe;
	
//	public void updateDetails_Google(ExeRecord_Google exeRec, TestSuite_Google lastTs, Accumulation accumulateExe, String selectedStage, 
//			double coeff_f, double coeff_e, boolean isExe, double coeff_s)
//	{
//		if(isExe) // if the test suite is executed
//		{
//			exeRec.updateTsRecord(lastTs,coeff_f,coeff_e, coeff_s);
//			lastTs.setExecuted(true);
//			//counting
//			accumulateExe.counting_Google(lastTs, selectedStage);		
//			this.accumulateExe = accumulateExe;
//		}
//		else //if test suite is not executed
//		{
//			exeRec.updateGrow(lastTs,coeff_f,coeff_e, coeff_s);
//		}
//		
//	}
	
	public void updateDetails_Travis(ExeRecord_Travis exeRec, TestSuite_Travis currentTs, Accumulation accumulateExe, boolean isExe, int commitNum,  double timePassed)
	{
		if(isExe)
		{
			exeRec.updateTsRecord(currentTs, commitNum);
			currentTs.setExecuted(true);
			
			//counting
			accumulateExe.counting_Travis_exe(currentTs,commitNum, timePassed);		
			this.accumulateExe = accumulateExe;
		}
	
		
		
		
	}

	
	public Accumulation getAccumulateExe() {
		return accumulateExe;
	}

	public void setAccumulateExe(Accumulation accumulateExe) {
		this.accumulateExe = accumulateExe;
	}
	
}
