package executeTS;

import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import testSuites.TestSuite_Travis;

public class StoreCommits 
{
	private Accumulation accumulateAll;
	private boolean isFirst;
	private int numOfCommit;
	private Commit exeCommit;
	private int commitId;
//	private Queue<Commit> allCommits;
	
	private PriorityQueue<Commit> pq; // put all commits in
	

	private double allCommitsDuration;
	private double avgCommitDuration;
	private double alltestExeTime;
	
	private int[] eachTestFailTimes;

	private Set<Integer> allbuilds;
	private double totalTests;
	
	public StoreCommits() 
	{
		super();
		this.accumulateAll = new Accumulation();
		this.isFirst = true;
		this.numOfCommit = 0;
		this.exeCommit = new Commit();
//		this.allCommits = new LinkedList<Commit>();
		this.pq = new PriorityQueue<Commit>(5000, new Comparator<Commit>(){
			public int compare(Commit c1, Commit c2)
			{				
				Timestamp c1_Arrive = c1.getCommitArrivalTime();
				Timestamp c2_Arrive = c2.getCommitArrivalTime();
//				System.out.println(c1_Arrive + ";" + c2_Arrive);
				if(c1_Arrive.before(c2_Arrive))
					return -1;
				else if(c1_Arrive.equals(c2_Arrive))
					return 0;
				else 
					return 1;	
			}
		});
		this.eachTestFailTimes = new int[2073];
		
		this.allbuilds = new HashSet<Integer>();
		
	}
	
	

	public void storeLastCommit()
	{
//		exeCommit.calculateDuration();
		allCommitsDuration += exeCommit.getDuration(); //durtion is different from exetime
		
		pq.offer(exeCommit);
		
		totalTests += exeCommit.getAllTests().size();
//		System.out.println(exeCommit.getAllTests().size());
//		System.out.println("avg number of tests per commit: " + totalTests/(double)numOfCommit);
		
//		Map<Integer, Double[]> map = exeCommit.getJobMap();
//		for(Integer i: map.keySet())
//		{
//			Double[] time = map.get(i);
//			System.out.println(time[0] + ","+ time[1] + ","+(time[0]>time[1]? "good": "not") );
//		}
		
//		System.out.println(exeCommit.getCommitId()+ "," + exeCommit.getCommitArrivalTime());
//		if(this.allbuilds.contains(exeCommit.getCommitId()))
//			System.out.println(exeCommit.getCommitId()+ "," + exeCommit.getCommitArrivalTime());
//		else
//			this.allbuilds.add(exeCommit.getCommitId());
		
//		if((exeCommit.isCheckFail() != exeCommit.isFailCommit()))
//		{
//			System.out.println(exeCommit.getCommitId() + ": build fail: " + exeCommit.isFailCommit() + "; but contains fails: " + exeCommit.isCheckFail() );
////			System.out.println(exeCommit.getCommitId());
//		}
	
//		if(exeCommit.isCheckFail())
//		{
//			System.out.print(numOfCommit+ ": ");
//			for(TestSuite_Travis ts: exeCommit.getFail())
//			{
//				System.out.print(ts.getTsId() + ",");
//			}
//			System.out.println();
//		}
		
//		int[] testFails = storeCommits.getEachTestFailTimes
//		alltestExeTime += exeCommit.getTotalExeTime();
//		System.out.println(alltestExeTime);
		System.out.println("total: "+allCommitsDuration);
		System.out.println("numOfCommit: " + numOfCommit);
		avgCommitDuration = allCommitsDuration/(double)numOfCommit;
		System.out.println("avg: "+avgCommitDuration);
		
		//system out the each distinct test suites' fail number
//		for(int i=0; i< 2073; i++)
//		{
//			System.out.println(i + "," + eachTestFailTimes[i]);
//		}
	}
	
	
	public void storeAllCommits(TestSuite_Travis currentTs, Set<Integer> notCompleteBuilds  )
	{
	
		//counting
		this.accumulateAll.counting_Travis_all(currentTs);
			
		if(isFirst)
		{
			numOfCommit ++;
			exeCommit.init(currentTs, eachTestFailTimes);	
			commitId = exeCommit.getCommitId();
				
			isFirst = false;					
		}		
						
		if(commitId == currentTs.getBuild_number())
		{
			exeCommit.storeTestsInCommit(currentTs);
		}
		else
		{	
//			exeCommit.calculateDuration();
			allCommitsDuration += exeCommit.getDuration(); //durtion is different from exetime
			alltestExeTime += exeCommit.getTotalExeTime();
//			System.out.println(alltestExeTime);
//			System.out.println(allCommitsDuration);
//			System.out.println(exeCommit.getDuration() + ":" + exeCommit.getTotalExeTime() +" : "+ exeCommit.getBuildStartTime() + " - "+ exeCommit.getBuildEndTime());
			pq.offer(exeCommit); // add the commit into the queue
		
//			totalTests += exeCommit.getAllTests().size();
//			System.out.println(exeCommit.getAllTests().size());
			
//			Map<Integer, Double[]> map = exeCommit.getJobMap();
//			for(Integer i: map.keySet())
//			{
//				Double[] time = map.get(i);
//				System.out.println(time[0] + ","+ time[1] + ","+(time[0]>time[1]? "good": "not") );
//			}
			
//			System.out.println(exeCommit.getBuildingTime());
			
//			if(this.allbuilds.contains(exeCommit.getCommitId()))
//				System.out.println(exeCommit.getCommitId()+ "," + exeCommit.getCommitArrivalTime());
//			else
//				this.allbuilds.add(exeCommit.getCommitId());
			
//			System.out.println(exeCommit.getCommitId()+ "," + exeCommit.getCommitArrivalTime());
//			if(exeCommit.isCheckFail())
//			{
//				System.out.print(numOfCommit+ ": ");
//				for(TestSuite_Travis ts: exeCommit.getFail())
//				{
//					System.out.print(ts.getTsId() + ",");
//				}
//				System.out.println();
//			}
			
//			if((exeCommit.isCheckFail() != exeCommit.isFailCommit()) && exeCommit.isFailCommit() == true)
//			{
//				System.out.println(exeCommit.getCommitId() + ":build fail: " + exeCommit.isFailCommit() + "; but contains fails: " + exeCommit.isCheckFail() );
////				System.out.println(exeCommit.getCommitId());
//			}
				
			
			numOfCommit ++;
//			exeNumOfCommit ++;
			exeCommit = new Commit();
			exeCommit.init(currentTs, eachTestFailTimes);	
			exeCommit.storeTestsInCommit(currentTs);
							
			commitId = exeCommit.getCommitId();
		}
		
	}

	
	public double getAvgCommitDuration()
	{
		avgCommitDuration = allCommitsDuration/(double)numOfCommit;
		
		return avgCommitDuration;
	}
		


	public int getNumOfCommit() {
		return numOfCommit;
	}

	public void setNumOfCommit(int numOfCommit) {
		this.numOfCommit = numOfCommit;
	}

	public Accumulation getAccumulateAll() {
		return accumulateAll;
	}

	public void setAccumulateAll(Accumulation accumulateAll) {
		this.accumulateAll = accumulateAll;
	}



	public PriorityQueue<Commit> getPq() {
		return pq;
	}



	public void setPq(PriorityQueue<Commit> pq) {
		this.pq = pq;
	}



	public double getAllCommitsDuration() {
		return allCommitsDuration;
	}



	public void setAllCommitsDuration(double allCommitsDuration) {
		this.allCommitsDuration = allCommitsDuration;
	}



	public void setAvgCommitDuration(double avgCommitDuration) {
		this.avgCommitDuration = avgCommitDuration;
	}

//
	
	

}
