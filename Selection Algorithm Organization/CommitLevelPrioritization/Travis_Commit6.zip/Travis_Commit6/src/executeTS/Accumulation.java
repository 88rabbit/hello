package executeTS;

import java.util.HashMap;
import java.util.Map;

import testSuites.TestSuite_Google;
import testSuites.TestSuite_Travis;

public class Accumulation 
{
	private double countNumber=0;
	private double countFailNumber=0;
	private double countExeTime=0;
	private double countFailExeTime = 0;
	
	private double ftotal = 0;
	private double ftotal_exeTime = 0;
	
	double timePassed = -1;
	double commitNum = -1;
	
	
	public void counting_Travis_all(TestSuite_Travis ts)
	{
		
//		countNumber++;
//		countTsDuration_Travis = countTsDuration_Travis + ts.getTs_duration();	
		
		/*
		 * This time we only consider failed test suite, but not considering "errored"
		 */
		
//		
		countNumber++;
		countExeTime = countExeTime + ts.getTs_duration();		
	
		if(ts.isFail_Ts())
		{
			countFailNumber++;
			countFailExeTime += ts.getTs_duration();
		}
		
	
	}
	
	public void counting_Travis_exe(TestSuite_Travis ts, int commitNum, double timePassed)
	{
		
//		countNumber++;
//		countTsDuration_Travis = countTsDuration_Travis + ts.getTs_duration();	
		
		if(commitNum != this.commitNum)
		{
			this.commitNum = commitNum;
			this.timePassed = timePassed;
		}
		
		
		/*
		 * This time we only consider failed test suite, but not considering "errored"
		 */
		
//		
		countNumber++;
		countExeTime = countExeTime + ts.getTs_duration();	
//		countTsDuration_Travis = countTsDuration_Travis + ts.getTs_duration();		
	
		
		this.timePassed +=  ts.getTs_duration();
		if(ts.isFail_Ts())
		{
			countFailNumber++;
			countFailExeTime += ts.getTs_duration();
			
			ftotal += countNumber;
			ftotal_exeTime += this.timePassed/(double)(1000*60*60);
//			double percentOfExeTime = countTsDuration_Travis/6548944.046051202;
//			System.out.println(countFailNumber+","+ percentOfExeTime*100);
		}
			
		
//		double totalNumber;
//		double totalExe;
//		
//		totalNumber = 2745655.0;
//		totalExe = 6548944.046051202;
//
//		
//		curPercent = countNumber/totalNumber;
//		curPercent_time = countTsDuration_Travis/totalExe;
//		
//		//time percent
////		System.out.println(lastPercent_time+","+expected+","+curPercent_time);
////		if(lastPercent_time <= expected_time && curPercent_time >= expected_time)
//		if(curPercent_time >= expected_time)
//		{
//			System.out.println((int)(expected_time*100) + ","+ countFailNumber);		
//			expected_time += 0.01;
////			if(expected == 0.53)
////				expected += 0.01;
//			
//		}
////		
////		//ts oercent
//		if(lastPercent <= expected_ts && curPercent >= expected_ts)
//		{
////			System.out.println((int)(expected_ts*100) + ","+ countFailNumber);
//			map.put((int)(expected_ts*100), countFailNumber);
//			expected_ts += 0.01;
//		}
//		
//		lastPercent = curPercent;
//		lastPercent_time = curPercent_time;
////		System.out.println(curPercent);
		
		
	}

	public double getCountNumber() {
		return countNumber;
	}

	public void setCountNumber(double countNumber) {
		this.countNumber = countNumber;
	}

	public double getCountFailNumber() {
		return countFailNumber;
	}

	public void setCountFailNumber(double countFailNumber) {
		this.countFailNumber = countFailNumber;
	}

	public double getCountExeTime() {
		return countExeTime;
	}

	public void setCountExeTime(double countExeTime) {
		this.countExeTime = countExeTime;
	}

	public double getFtotal() {
		return ftotal;
	}

	public void setFtotal(double ftotal) {
		this.ftotal = ftotal;
	}


	public double getCountFailExeTime() {
		return countFailExeTime;
	}

	public void setCountFailExeTime(double countFailExeTime) {
		this.countFailExeTime = countFailExeTime;
	}

	public double getFtotal_exeTime() {
		return ftotal_exeTime;
	}

	public void setFtotal_exeTime(double ftotal_exeTime) {
		this.ftotal_exeTime = ftotal_exeTime;
	}
	
	

	

	
}
