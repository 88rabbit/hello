//package executeTS;
//
//import java.sql.Timestamp;
//import java.util.PriorityQueue;
//import java.util.Set;
//import exeRecord.ExeRecord_Google;
//import exeRecord.ExeRecord_Travis;
//import testSuites.TestSuite_Google;
//import testSuites.TestSuite_Travis;
//
//public class CombineCommits 
//{	
//	
//	//for counting number of all TestSuites
//	private Accumulation accumulateAll = new Accumulation();
//			
//	//for counting number of executed TestSuites
//	private Accumulation accumulateExe = new Accumulation();
//	
//
//	private boolean isFrist = true;
////	private int totalCommits = 0;
////	private int executedCommits = 0;
//	private Commit exeCommit = new Commit();
//	
//	private int commitId;
//	private int failCommits;
//	private int failBuilds;
//	
//	private double totalExeTime;
//	
//	private int commitsStar = 0;
//	private int stars = 0;
//	private UpdateExeRecord updateExeRecords;
//	
//	private double commitFailApfd = 0;
//	private double commitAllApfd = 0;
//	private int exeNumOfCommit = 0;
//	private int detectedFailCommits = 0;
//	//newly added
//	private int numOfCommit = 0;
////	private CountFailures cf= new CountFailures();
//	
//	private int pqSize;
//	private double train;
//	private double trainingSize;
//	
//	
//	public CombineCommits(int pqSize, double trainingSize) 
//	{
//		super();
//		this.pqSize = pqSize;
//		this.updateExeRecords = new UpdateExeRecord();
//		this.trainingSize = trainingSize;
//		this.train = (double)((double)trainingSize*(double)3680);
//	}
//
//	
//	
//	public void selectTs_Travis(TestSuite_Travis currentTs, ExeRecord_Travis exeRec, int failCommitWindow, int exeCommitWindow, PrioritizeCommits prioritizeCommits, double comparedNum, int pqSize, Set<Integer> notCompleteBuilds  )
//	{
//				
//			//counting
//			this.accumulateAll.counting_Travis_all(currentTs);
//			
//			if(isFrist)
//			{
//				numOfCommit ++;
//				exeCommit.init(currentTs);	
//				commitId = exeCommit.getCommitId();
//				
//				isFrist = false;	
//				
//			}			
//					
//			if(commitId == currentTs.getBuild_number())
//			{
//				exeCommit.update(currentTs, exeRec, failCommitWindow, exeCommitWindow, exeNumOfCommit+1);
//			}
//			else
//			{
////				System.out.println(exeCommit.getId());
//				
////				CountCommits.updateCountsInQueue(); // update number
//				prioritizeCommits.updateCommits(exeCommit); // prioritize commits
//								
//				if( prioritizeCommits.getPq().size() == this.pqSize) // prioritize window = 5
//				{
////					System.out.println(pqSize);
//					exeNumOfCommit ++;
//					Commit c =  prioritizeCommits.getPq().poll();	
//					c.updateProcessCommit(accumulateExe, exeRec, updateExeRecords, exeNumOfCommit);
////					System.out.println(c.getId() + ":idididi" + prioritizeCommits.getPq().size());
//									
//					commitAllApfd ++; 
//					if(c.isCheckFail())
//					{
//						commitFailApfd += commitAllApfd;
//						failCommits ++;
//						detectedFailCommits ++;
//		//				System.out.println(commitAllApfd);
//					}		
////						System.out.println(failCommits);
////						System.out.println("fail ratio: "+ c.getFailRatio()
////											   + ", exe ratio: " + c.getExeRatio() 
////											   + ", % of fail: " + c.getRatio_fail());
////						System.out.println(failCommits);
////						
//					prioritizeCommits.updateInformInnerCommits(accumulateExe, exeRec, failCommitWindow, exeCommitWindow, exeNumOfCommit);
//				}
//					
//					
//					numOfCommit ++;
////					exeNumOfCommit ++;
//					exeCommit = new Commit();
//					exeCommit.init(currentTs);	
//					exeCommit.update(currentTs, exeRec, failCommitWindow, exeCommitWindow, exeNumOfCommit+1);
//							
//					commitId = exeCommit.getCommitId();
//			
//			}
//		
//		
//	}
//	
//	
//	public void processLastCommit(ExeRecord_Travis exeRec, CountCommits CountCommits, int failCommitWindow, int exeCommitWindow, PrioritizeCommits prioritizeCommits)
//	{
//		prioritizeCommits.updateCommits(exeCommit); // prioritize commits
//		while(! prioritizeCommits.getPq().isEmpty())
//		{
//			exeNumOfCommit ++;
//			Commit c =  prioritizeCommits.getPq().poll();					
//			c.updateProcessCommit(accumulateExe, exeRec, updateExeRecords, exeNumOfCommit);
//						
//			commitAllApfd ++; 
//			if(c.isCheckFail())
//			{
//				commitFailApfd += commitAllApfd;
//				failCommits ++;
//				detectedFailCommits ++;
////				System.out.println(commitAllApfd);
//			}
////			System.out.println(failCommits);
//		}
//		
//
//		
//
//	}
//	
//	
////	public void selectTs_Travis(TestSuite_Travis currentTs, ExeRecord_Travis exeRec, double coeff_f, double coeff_e, double comparedNum, double coeff_s, Set<Integer> notCompleteBuilds )
////	{
////		/*
////		 * update the number of TestSuite and the execution time of TestSuite
////		 */
//////		if(currentTs.getTs_state().equals("errored"))
//////		{
//////			//skip
//////		}
//////		else
//////		if(currentTs.getBuild_state().equals("passed"))
////		{
////			//counting
////			this.accumulateAll.counting_Travis_all(currentTs);
////			
////			if(isFrist)
////			{
////				totalCommits++;
////				exeCommit.init(currentTs);
////				commitId = exeCommit.getCommitId();
////				isFrist = false;			
////			}			
////			
////			if(commitId == currentTs.getBuild_number())
////			{
////				exeCommit.update(currentTs);
////				
////			} 
////			else
////			{
//////				
////					executedCommits ++;
////					exeCommit.updateProcessCommit(accumulateExe);
////															
////					
////					/*
////					 * For output results
////					 */
////					if(exeCommit.isFail())
////						failCommits++;
////					if(exeCommit.getIsFailBuild() == 1)
////						failBuilds ++;
////					
////					if(exeCommit.isContainStars())
////					{
////						commitsStar++;
////						stars += exeCommit.getStarTs();
////					}
////					
////				
////				
////				exeCommit = new Commit();
////				totalCommits++;
////				exeCommit.init(currentTs);	
////				exeCommit.update(currentTs);		
////			}
////			
////			commitId = exeCommit.getCommitId();
////		}
////		
////		
////		
////	}
////	
////	
////	public void processLastCommit()
////	{
////		exeCommit.updateProcessCommit(accumulateExe);
////	}
////	
//	
//	
//	
//		
//
//	public Accumulation getAccumulateAll() {
//		return accumulateAll;
//	}
//
//	public void setAccumulateAll(Accumulation accumulateAll) {
//		this.accumulateAll = accumulateAll;
//	}
//
//	public Accumulation getAccumulateExe() {
//		return accumulateExe;
//	}
//
//	public void setAccumulateExe(Accumulation accumulateExe) {
//		this.accumulateExe = accumulateExe;
//	}
//
//
//	public Commit getExeCommit() {
//		return exeCommit;
//	}
//
//	public void setExeCommit(Commit exeCommit) {
//		this.exeCommit = exeCommit;
//	}
//
//	public int getCommitId() {
//		return commitId;
//	}
//
//	public void setCommitId(int commitId) {
//		this.commitId = commitId;
//	}
//
//	public int getFailCommits() {
//		return failCommits;
//	}
//
//	public void setFailCommits(int failCommits) {
//		this.failCommits = failCommits;
//	}
//
//	public int getFailBuilds() {
//		return failBuilds;
//	}
//	
//	public void setFailBuilds(int failBuilds) {
//		this.failBuilds = failBuilds;
//	}
//
//	public int getCommitsStar() {
//		return commitsStar;
//	}
//
//
//	public void setCommitsStar(int commitsStar) {
//		this.commitsStar = commitsStar;
//	}
//
//
//	public int getStars() {
//		return stars;
//	}
//
//
//	public void setStars(int stars) {
//		this.stars = stars;
//	}
//
//
//
//	public boolean isFrist() {
//		return isFrist;
//	}
//
//
//
//	public void setFrist(boolean isFrist) {
//		this.isFrist = isFrist;
//	}
//
//
//
//	public double getTotalExeTime() {
//		return totalExeTime;
//	}
//
//
//
//	public void setTotalExeTime(double totalExeTime) {
//		this.totalExeTime = totalExeTime;
//	}
//
//
//
//	public UpdateExeRecord getUpdateExeRecords() {
//		return updateExeRecords;
//	}
//
//
//
//	public void setUpdateExeRecords(UpdateExeRecord updateExeRecords) {
//		this.updateExeRecords = updateExeRecords;
//	}
//
//
//
//	public double getCommitFailApfd() {
//		return commitFailApfd;
//	}
//
//
//
//	public void setCommitFailApfd(double commitFailApfd) {
//		this.commitFailApfd = commitFailApfd;
//	}
//
//
//
//	public double getCommitAllApfd() {
//		return commitAllApfd;
//	}
//
//
//
//	public void setCommitAllApfd(double commitAllApfd) {
//		this.commitAllApfd = commitAllApfd;
//	}
//
//
//
//	public int getNumOfCommit() {
//		return numOfCommit;
//	}
//
//
//
//	public void setNumOfCommit(int numOfCommit) {
//		this.numOfCommit = numOfCommit;
//	}
//
//
//
//	public int getPqSize() {
//		return pqSize;
//	}
//
//
//
//	public void setPqSize(int pqSize) {
//		this.pqSize = pqSize;
//	}
//
//
//
//	public int getExeNumOfCommit() {
//		return exeNumOfCommit;
//	}
//
//
//
//	public void setExeNumOfCommit(int exeNumOfCommit) {
//		this.exeNumOfCommit = exeNumOfCommit;
//	}
//
//
//
//	public int getDetectedFailCommits() {
//		return detectedFailCommits;
//	}
//
//
//
//	public void setDetectedFailCommits(int detectedFailCommits) {
//		this.detectedFailCommits = detectedFailCommits;
//	}
//
//	
//	
//	
//	
//}
