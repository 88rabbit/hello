package executeTS;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import exeRecord.ExeRecord_Travis;
import readFile.ReadData;
import testSuites.TestSuite_Travis;

public class ExecuteTestSuites_Travis 
{
	private double all_TSnumber = 0;
	private double all_failNumber=0;
	private double all_ExeTime_Travis=0;
	
	private double executed_TSnumber = 0;
	private double executed_failNumber=0;
	private double executed_ExeTime_Travis=0;
	private double ftotal_exeTime= 0;

	private TestSuite_Travis currentTs;
		
	private Set<Integer> notCompleteBuilds;
	
	private double ftotal;
		
	private ExeRecord_Travis exeRec = new ExeRecord_Travis();
//	private CombineCommits combineCommits;
	private CountCommits CountCommits ;
	private PrioritizeCommits prioritizeCommits;
	
	private Map<Integer, Double> map = new HashMap<Integer, Double>();
	
	/*
	 * simulate the real sinario
	 */
	private StoreCommits storeCommits;
	
	
	private Timestamp build_startTime;
	private Timestamp build_endTime;
//	private double lastTsExeTime;
//	private double totalTime;
	private boolean isFirstBuild = true;;
	private double totalTimeLine;
	private SimulateCommitsExecution simulateCommitExe;
	private boolean isIntra;
	
	
	public ExecuteTestSuites_Travis(ExeRecord_Travis exeRec, int pqSize, double trainingSize, boolean isIntra) 
	{
		super();
		CountCommits = new CountCommits();
		prioritizeCommits = new PrioritizeCommits();
//		combineCommits = new CombineCommits(pqSize, trainingSize);
		this.exeRec = exeRec;
		this.isIntra = isIntra;		
		this.storeCommits = new StoreCommits(); 
		this.isIntra = isIntra;
	}

	public void executeTestSuites(ResultSet rs, int failWindow, int executionWindow,String failmmhh, String executemmhh,int distinctTsNum, 
			int repetiveWindow, String repetivemmhh, int failCommitWindow, int exeCommitWindow, double rate, int numOfProcessor)
	{	
		
		//for updating the exeRecord
		
		exeRec.initializeRecord(distinctTsNum);
		ReadData rd = new ReadData();
		notCompleteBuilds = rd.readNotCompleteBuilds();
		
//		String testName;
		Timestamp ts_start_time;
		String ts_state;
		int currentId;
		int ts_order_in_job;
		double ts_duration; 
		int ts_runs; 
		int ts_assertions; 
		int ts_failures;
		int ts_errors;
		int ts_skips; 
		int build_number;
		String build_state;
		Timestamp build_start_time; 
		Timestamp build_finish_time; 
		double build_duration; 
		
		int job_id;
		int job_allow_failure;
		Timestamp job_start_time; 
		Timestamp job_finish_time;
		double job_duration; 
		String commit_sha; 
		String job_state;
		
		boolean isStar = false;
		
		try {
				while(rs.next())
				{	
//					testName = (String)rs.getNString("TestSuite");
//					if(testName.toLowerCase().contains("*"))
//					{
//						isStar = true;
//					}
					
					currentId= rs.getInt("Ts_id");
					ts_order_in_job = rs.getInt("Ts_order_in_job");
					ts_start_time= rs.getTimestamp("Ts_start_time");				
					ts_duration = rs.getDouble("Ts_duration");
					ts_runs = rs.getInt("Ts_runs"); 
					ts_assertions = rs.getInt("Ts_assertions"); 
					ts_failures = rs.getInt("Ts_failures");
					ts_errors = rs.getInt("Ts_errors");
					ts_skips = rs.getInt("Ts_skips"); 
					
//					build_id = rs.getInt("Build_id");
					build_number = rs.getInt("Build_number");
					build_state = rs.getString("Build_state");
					build_start_time = rs.getTimestamp("Build_start_time"); 
					build_finish_time = rs.getTimestamp("Build_finish_time"); 
					build_duration = rs.getDouble("Build_duration"); 
					
					job_id = rs.getInt("Job_id");
//					job_number = rs.getInt("Job_number"); 
				    job_state = rs.getString("Job_state"); 
					job_start_time = rs.getTimestamp("Job_start_time"); 
					job_allow_failure = rs.getInt("Job_allow_failure");
					job_finish_time = rs.getTimestamp("Job_finish_time");
//					job_duration = rs.getDouble("Job_duration")*1000; 
					
					commit_sha = rs.getString("Commit_sha"); 

				
					//update currentTs
					currentTs = new TestSuite_Travis(currentId, ts_order_in_job, ts_duration, ts_runs, ts_assertions, ts_failures, ts_errors, ts_skips, 
							 build_number, build_state, build_start_time, build_finish_time, build_duration, job_id, job_start_time, job_finish_time, job_allow_failure, commit_sha);		
					ts_state = currentTs.getTs_state();
					
					
//					System.out.println(currentId +"," + ts_order_in_job +"," + ts_duration + "," +ts_runs + "," + ts_assertions+","+
//							ts_failures + ","+ ts_errors+ ","+ts_skips + "," +build_number+ ","+build_state+","+build_start_time 
//							+ ","+build_finish_time + "," + build_duration + ","+job_id + "," + job_start_time+  "," + job_finish_time +","+job_allow_failure +  "," +commit_sha + ","+ job_state);
////					
					/*
//					 * update the number of TestSuite and the execution time of TestSuite by calling the methods in UpdateTs
//					 */
//					if(!notCompleteBuilds.contains(currentTs.getBuild_number()))
//						combineCommits.selectTs_Travis(currentTs, exeRec, failCommitWindow, exeCommitWindow, prioritizeCommits, comparedNum, pqSize, notCompleteBuilds );
					
					/*
					 * Simulate the queue in a real snario
					 */
					if(!notCompleteBuilds.contains(currentTs.getBuild_number()))
					{
						storeCommits.storeAllCommits(currentTs, notCompleteBuilds);
						System.out.println(currentId +"," + ts_order_in_job +"," + ts_duration + "," +ts_runs + "," + ts_assertions+","+
								ts_failures + ","+ ts_errors+ ","+ts_skips + "," +build_number+ ","+build_state+","+build_start_time 
								+ ","+build_finish_time + "," + build_duration + ","+job_id + "," + job_start_time+  "," + job_finish_time +"," +job_allow_failure +  "," +commit_sha + ","+ job_state + ","+ ts_start_time);
//						
					}
					
					if(isFirstBuild)
					{
						build_startTime = currentTs.getBuild_start_time();
//						System.out.println(build_startTime);
						isFirstBuild = false;
					}
				}		 
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		if(!notCompleteBuilds.contains(currentTs.getBuild_number()))
//			combineCommits.selectTs_Travis(currentTs, exeRec, failCommitWindow, exeCommitWindow, prioritizeCommits, comparedNum, pqSize, notCompleteBuilds );
//		
//		combineCommits.processLastCommit(exeRec, CountCommits, failWindow, executionWindow, prioritizeCommits);// newest
//		
//		this.all_TSnumber = combineCommits.getAccumulateAll().getCountNumber();
//		this.all_failNumber=combineCommits.getAccumulateAll().getCountFailNumber();
//		this.all_ExeTime_Travis = combineCommits.getAccumulateAll().getCountTsDuration_Travis();
//		
//		this.executed_TSnumber = combineCommits.getAccumulateExe().getCountNumber();
//		this.executed_failNumber=combineCommits.getAccumulateExe().getCountFailNumber();
//		this.executed_ExeTime_Travis= combineCommits.getAccumulateExe().getCountTsDuration_Travis();	
//		
//		this.ftotal = combineCommits.getAccumulateExe().getFtotal();
//		this.map = combineCommits.getAccumulateExe().getMap();
		
		if(!notCompleteBuilds.contains(currentTs.getBuild_number()))
			storeCommits.storeAllCommits(currentTs, notCompleteBuilds);
		storeCommits.storeLastCommit();
		
		//normalize the timeline
		this.build_endTime = currentTs.getBuild_finish_time();// get the end time of the lastTs
		this.totalTimeLine = build_endTime.getTime() - build_startTime.getTime();
//		System.out.println(build_startTime + "; " + build_endTime);
//		System.out.println(totalTimeLine); // millisecond
//		
//		
//		System.out.println(storeCommits.getNumOfCommit());
//		System.out.println("total Time(ms): "+(1000*storeCommits.getAccumulateAll().getCountExeTime()) + "; number: "+storeCommits.getAccumulateAll().getCountNumber() + "; fail Number: "+ storeCommits.getAccumulateAll().getCountFailNumber());
//		
//		/*
//		 * process the commits
//		 */
////		this.simulateCommitExe = new SimulateCommitsExecution(this.storeCommits, this.totalTimeLine);
////		this.simulateCommitExe.simulateProcess();
////		System.out.println("exeCommit" + this.simulateCommitExe.getNumOfCommitExe());
////		System.out.println(this.totalTimeLine);
////		
////		System.out.println(this.simulateCommitExe.getQueue().size());
//		
//
////		totalTimeLine = (double)18178496377.00;
//		
////		totalTimeLine = this.storeCommits.getAllCommitsDuration();
//		
//		System.out.println("get all time: "+ totalTimeLine);
//		
		this.simulateCommitExe = new SimulateCommitsExecution(this.storeCommits, this.totalTimeLine,  this.isIntra);
//		this.simulateCommitExe.setConcurrent();
		//prioritize
		this.simulateCommitExe.simulateProcess(prioritizeCommits, exeRec, failWindow, executionWindow, numOfProcessor, rate);
	
	
	
	
		this.all_TSnumber = storeCommits.getAccumulateAll().getCountNumber();
		this.all_failNumber = storeCommits.getAccumulateAll().getCountFailNumber();
		this.all_ExeTime_Travis = storeCommits.getAccumulateAll().getCountExeTime();
//		this.allFailExeTime_Travis = storeCommits.getAccumulateAll().getAllFailExeTime();
		
		this.executed_TSnumber = simulateCommitExe.getAccumulateExe().getCountNumber();
		this.executed_failNumber=simulateCommitExe.getAccumulateExe().getCountFailNumber();
		this.executed_ExeTime_Travis = simulateCommitExe.getAccumulateExe().getCountExeTime();	
//		
		this.ftotal = simulateCommitExe.getAccumulateExe().getFtotal();
		this.ftotal_exeTime = simulateCommitExe.getAccumulateExe().getFtotal_exeTime();
//		this.map = simulateCommitExe.getAccumulateExe().getMap();
	}

	public double getAll_TSnumber() {
		return all_TSnumber;
	}

	public void setAll_TSnumber(double all_TSnumber) {
		this.all_TSnumber = all_TSnumber;
	}

	public double getAll_failNumber() {
		return all_failNumber;
	}

	public void setAll_failNumber(double all_failNumber) {
		this.all_failNumber = all_failNumber;
	}

	public double getAll_ExeTime_Travis() {
		return all_ExeTime_Travis;
	}

	public void setAll_ExeTime_Travis(double all_ExeTime_Travis) {
		this.all_ExeTime_Travis = all_ExeTime_Travis;
	}

	public double getExecuted_TSnumber() {
		return executed_TSnumber;
	}

	public void setExecuted_TSnumber(double executed_TSnumber) {
		this.executed_TSnumber = executed_TSnumber;
	}

	public double getExecuted_failNumber() {
		return executed_failNumber;
	}

	public void setExecuted_failNumber(double executed_failNumber) {
		this.executed_failNumber = executed_failNumber;
	}

	public double getExecuted_ExeTime_Travis() {
		return executed_ExeTime_Travis;
	}

	public void setExecuted_ExeTime_Travis(double executed_ExeTime_Travis) {
		this.executed_ExeTime_Travis = executed_ExeTime_Travis;
	}

	public TestSuite_Travis getCurrentTs() {
		return currentTs;
	}

	public void setCurrentTs(TestSuite_Travis currentTs) {
		this.currentTs = currentTs;
	}

	public ExeRecord_Travis getExeRec() {
		return exeRec;
	}

	public void setExeRec(ExeRecord_Travis exeRec) {
		this.exeRec = exeRec;
	}


	public double getFtotal() {
		return ftotal;
	}

	public void setFtotal(double ftotal) {
		this.ftotal = ftotal;
	}

	public Map<Integer, Double> getMap() {
		return map;
	}

	public void setMap(Map<Integer, Double> map) {
		this.map = map;
	}

	public Set<Integer> getNotCompleteBuilds() {
		return notCompleteBuilds;
	}

	public void setNotCompleteBuilds(Set<Integer> notCompleteBuilds) {
		this.notCompleteBuilds = notCompleteBuilds;
	}

//	public CombineCommits getCombineCommits() {
//		return combineCommits;
//	}
//
//	public void setCombineCommits(CombineCommits combineCommits) {
//		this.combineCommits = combineCommits;
//	}

	public CountCommits getCountCommits() {
		return CountCommits;
	}

	public void setCountCommits(CountCommits countCommits) {
		CountCommits = countCommits;
	}

	public PrioritizeCommits getPrioritizeCommits() {
		return prioritizeCommits;
	}

	public void setPrioritizeCommits(PrioritizeCommits prioritizeCommits) {
		this.prioritizeCommits = prioritizeCommits;
	}

	public double getFtotal_exeTime() {
		return ftotal_exeTime;
	}

	public void setFtotal_exeTime(double ftotal_exeTime) {
		this.ftotal_exeTime = ftotal_exeTime;
	}

	public StoreCommits getStoreCommits() {
		return storeCommits;
	}

	public void setStoreCommits(StoreCommits storeCommits) {
		this.storeCommits = storeCommits;
	}

	public Timestamp getBuild_startTime() {
		return build_startTime;
	}

	public void setBuild_startTime(Timestamp build_startTime) {
		this.build_startTime = build_startTime;
	}

	public Timestamp getBuild_endTime() {
		return build_endTime;
	}

	public void setBuild_endTime(Timestamp build_endTime) {
		this.build_endTime = build_endTime;
	}

	public boolean isFirstBuild() {
		return isFirstBuild;
	}

	public void setFirstBuild(boolean isFirstBuild) {
		this.isFirstBuild = isFirstBuild;
	}

	public double getTotalTimeLine() {
		return totalTimeLine;
	}

	public void setTotalTimeLine(double totalTimeLine) {
		this.totalTimeLine = totalTimeLine;
	}

	public SimulateCommitsExecution getSimulateCommitExe() {
		return simulateCommitExe;
	}

	public void setSimulateCommitExe(SimulateCommitsExecution simulateCommitExe) {
		this.simulateCommitExe = simulateCommitExe;
	}

	public boolean isIntra() {
		return isIntra;
	}

	public void setIntra(boolean isIntra) {
		this.isIntra = isIntra;
	}
	


}
