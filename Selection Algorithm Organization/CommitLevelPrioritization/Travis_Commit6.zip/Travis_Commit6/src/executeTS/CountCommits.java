package executeTS;

public class CountCommits 
{

	private int commitsNum;

	public CountCommits() 
	{
		super();
		this.commitsNum = 0;
	}

	public void updateCountsInQueue()
	{
		commitsNum ++;

	}

	public void resetCounts()
	{
		commitsNum = 0;
	}

	public int getCommitsNum() {
		return commitsNum;
	}

	public void setCommitsNum(int commitsNum) {
		this.commitsNum = commitsNum;
	}
}
