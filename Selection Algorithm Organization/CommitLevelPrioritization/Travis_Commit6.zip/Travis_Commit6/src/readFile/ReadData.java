package readFile;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashSet;
import java.util.Set;

public class ReadData 
{
	private int total = 0;
	
	public Set<Integer> readNotCompleteBuilds()
	{
		Set<Integer> builds = new HashSet<Integer>();
		try
		{
//			
			FileReader fs = new FileReader("../data/notCompleteBuilds.txt"); // the commits contains test suites that has failure history(does not mean it fails)
			
			BufferedReader br = new BufferedReader(fs);
			
			String testInfo = br.readLine();
			int curBuild = 0;
			while(testInfo!=null &&!testInfo.isEmpty())
			{		
				total ++;
				//parse file contents
				curBuild = Integer.parseInt(testInfo);
				
				builds.add(curBuild);
							
				testInfo = br.readLine();			
			
			}
//			System.out.println("No. of builds that are not complete" + total);	
//			System.out.println(c + "records have been inserted");
		}
		catch(Exception e)
		{
			System.out.print(e.toString());
		}
		
		return builds;
	}
	
}
