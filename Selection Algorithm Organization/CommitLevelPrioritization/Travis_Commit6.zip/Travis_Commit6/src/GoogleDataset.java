import java.sql.SQLException;

import parsingCommandLine.Cli;
import simulate.Simulation;

public class GoogleDataset 
{
	public void getGoogleDataset(String[] newString) throws ClassNotFoundException, SQLException
	{
		//adding options for command lines
		/*
		 * -a,--failureWindow <arg>        set the failureWindow(integers)
			 -b,--executionWindow <arg>      set the executionWindow(integers)
			 -c,--failmmhh <arg>             set the minutes or hours for failure
			                                 window('minutes' or 'hours')
			 -d,--executemmhh <arg>          set the minutes or hours for execution
			                                 window('minutes' or 'hours')
			 -e,--alwaySelectedStage <arg>   set the stage('pres' or 'post' or '') in
			                                 which the tests will always execute.
			 -h,--help                       show help
			 -s,--selectedStage <arg>        set the selected stage('pres' or 'post'
			                                 or 'presAndPost')
		 */
				
		
		//setting the sql
//		private static String sql = "SELECT TestSuite, ChangeRequest, Stage, Status_test, LaunchTime, ExecutionTime,size, Shared_number, Run_number, Language_test, T_number FROM AllData ORDER BY LaunchTime, T_number, Shared_number";
		String sql = "SELECT ChangeRequest, Stage, Status_test, LaunchTime, ExecutionTime,size, Shared_number, Run_number, Language_test, T_number,  TestId FROM AllData ORDER BY LaunchTime, T_number, Shared_number";
//		private static String sql = "SELECT TestSuite, ChangeRequest, Stage, Status_test, LaunchTime, ExecutionTime,size, Shared_number, Run_number, Language_test, T_number FROM AllData Where T_Number = '3430' ORDER BY LaunchTime, T_number, Shared_number";
				
		int distinctTsNum = 5556;
		
		String alwaysExecutedStage = newString[7];
		
		int failWindow=Integer.parseInt(newString[1]);
		int executionWindow=Integer.parseInt(newString[2]);
		
		// setting the followings, Strings should be "minutes" or "hours"
		String failmmhh= newString[3];
		String executemmhh = newString[4];
		
		int repetiveWindow = Integer.parseInt(newString[5]);
		String repetivemmhh = newString[6];
		
		// setting the phase of testSuites
		String selectedStage = newString[8];	
		
		double coeff_f = Double.parseDouble(newString[9]);
		double coeff_e = Double.parseDouble(newString[10]);
		double comparedNum = Double.parseDouble(newString[11]);
		double coeff_s = Double.parseDouble(newString[12]);
		
		
		Simulation simulation = new Simulation();
//		simulation.simulate_Google(sql, failWindow, executionWindow, failmmhh, executemmhh, selectedStage, distinctTsNum, alwaysExecutedStage, repetiveWindow, repetivemmhh, coeff_f, coeff_e, comparedNum, coeff_s);
	}
	
}
