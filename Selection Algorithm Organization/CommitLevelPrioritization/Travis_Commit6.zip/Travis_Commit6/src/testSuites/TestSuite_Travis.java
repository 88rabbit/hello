package testSuites;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

public class TestSuite_Travis 
{
	private boolean isExecuted=false;
	
	private boolean isFail_Ts=false;
//	private boolean isError_Ts = false;
//	private String initialFailTime = "Inf.";
	
//	private Timestamp Ts_failTime; //Ts_start_time
	private String Ts_state;
	
	private int TsId;
	private int Ts_order_in_job;
	private double Ts_duration;	 //Ts execution time
	private int Ts_runs;
	private int Ts_assertions;
	private int Ts_failures;
	private int Ts_errors;
	private int Ts_skips;
	
	private int Build_number;
	private String Build_state;
	private Timestamp Build_start_time;
	private Timestamp Build_finish_time;
	private double Build_duration;
//	private double resetExeTime;
	
	private int Job_id;
	private Timestamp Job_start_time;	
	private int Job_allow_failure;
	
	private String Commit_sha;
	
//	private int Job_number;
//	private String Job_state;
	private Timestamp Job_finish_time;
//	private double Job_duration;
//	private boolean isStar;

	//for initialization
	public TestSuite_Travis(int tsId) {
		super();
		TsId = tsId;
	}
	
	//if each Ts is executed, the related record will be updated
	public TestSuite_Travis(int tsId, int ts_order_in_job, double ts_duration, int ts_runs, int ts_assertions, int ts_failures,
			int ts_errors, int ts_skips, int build_number, String build_state, Timestamp build_start_time, Timestamp build_finish_time, 
			double build_duration,int job_id, Timestamp job_start_time, Timestamp job_finish_time, int job_allow_failure, String commit_sha) 
	{
		super();
				
		TsId = tsId;	
		Ts_order_in_job = ts_order_in_job;
		Ts_duration = ts_duration;		
		Ts_runs = ts_runs;
		Ts_assertions = ts_assertions;
		Ts_failures = ts_failures;
		Ts_errors = ts_errors;
		Ts_skips = ts_skips;
	
		Build_number = build_number;
		Build_state = build_state;
		Build_start_time = build_start_time;
		Build_finish_time = build_finish_time;
		Build_duration = build_duration;
		Job_id = job_id;
		Job_start_time = job_start_time;
		Job_finish_time = job_finish_time;
		
		Job_allow_failure = job_allow_failure;
		if(job_allow_failure == 0)
		{
			if(ts_failures>0)
			{
				Ts_state = "failed";
//				this.Ts_failTime = ts_start_time;
				this.isFail_Ts =true;
			}
			else
			{
				Ts_state = "passed";
			}
		}
		else
			Ts_state = "passed";
		
//		
		Commit_sha = commit_sha;
		
		
	}

	public Timestamp getJob_finish_time() {
		return Job_finish_time;
	}

	public void setJob_finish_time(Timestamp job_finish_time) {
		Job_finish_time = job_finish_time;
	}

	public boolean isExecuted() {
		return isExecuted;
	}

	public void setExecuted(boolean isExecuted) {
		this.isExecuted = isExecuted;
	}

	public boolean isFail_Ts() {
		return isFail_Ts;
	}

	public void setFail_Ts(boolean isFail_Ts) {
		this.isFail_Ts = isFail_Ts;
	}
//
//	public Timestamp getTs_failTime() {
//		return Ts_failTime;
//	}
//
//	public void setTs_failTime(Timestamp ts_failTime) {
//		Ts_failTime = ts_failTime;
//		this.isFail_Ts = true; // also update this.isFail
//		this.Ts_state ="failed";
//	}

	public String getTs_state() {
		return Ts_state;
	}

	public void setTs_state(String ts_state) {
		Ts_state = ts_state;
	}

	public int getTsId() {
		return TsId;
	}

	public void setTsId(int tsId) {
		TsId = tsId;
	}

	public double getTs_duration() {
		return Ts_duration;
	}

	public void setTs_duration(double ts_duration) {
		Ts_duration = ts_duration;
	}

	public int getTs_runs() {
		return Ts_runs;
	}

	public void setTs_runs(int ts_runs) {
		Ts_runs = ts_runs;
	}

	public int getTs_assertions() {
		return Ts_assertions;
	}

	public void setTs_assertions(int ts_assertions) {
		Ts_assertions = ts_assertions;
	}

	public int getTs_failures() {
		return Ts_failures;
	}

	public void setTs_failures(int ts_failures) {
		Ts_failures = ts_failures;
	}

	public int getTs_errors() {
		return Ts_errors;
	}

	public void setTs_errors(int ts_errors) {
		Ts_errors = ts_errors;
	}

	public int getTs_skips() {
		return Ts_skips;
	}

	public void setTs_skips(int ts_skips) {
		Ts_skips = ts_skips;
	}

	public int getBuild_number() {
		return Build_number;
	}

	public void setBuild_number(int build_number) {
		Build_number = build_number;
	}

	public String getBuild_state() {
		return Build_state;
	}

	public void setBuild_state(String build_state) {
		Build_state = build_state;
	}

	public Timestamp getBuild_start_time() {
		return Build_start_time;
	}

	public void setBuild_start_time(Timestamp build_start_time) {
		Build_start_time = build_start_time;
	}

	public Timestamp getBuild_finish_time() {
		return Build_finish_time;
	}

	public void setBuild_finish_time(Timestamp build_finish_time) {
		Build_finish_time = build_finish_time;
	}

	public double getBuild_duration() {
		return Build_duration;
	}

	public void setBuild_duration(double build_duration) {
		Build_duration = build_duration;
	}

	public int getTs_order_in_job() {
		return Ts_order_in_job;
	}

	public void setTs_order_in_job(int ts_order_in_job) {
		Ts_order_in_job = ts_order_in_job;
	}

	public int getJob_id() {
		return Job_id;
	}

	public void setJob_id(int job_id) {
		Job_id = job_id;
	}

	public Timestamp getJob_start_time() {
		return Job_start_time;
	}

	public void setJob_start_time(Timestamp job_start_time) {
		Job_start_time = job_start_time;
	}

	public int getJob_allow_failure() {
		return Job_allow_failure;
	}

	public void setJob_allow_failure(int job_allow_failure) {
		Job_allow_failure = job_allow_failure;
	}

	public String getCommit_sha() {
		return Commit_sha;
	}

	public void setCommit_sha(String commit_sha) {
		Commit_sha = commit_sha;
	}

	




	

}
