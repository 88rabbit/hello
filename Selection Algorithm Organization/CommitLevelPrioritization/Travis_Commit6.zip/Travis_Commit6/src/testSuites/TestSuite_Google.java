package testSuites;
import java.sql.Timestamp;

//this class is used for create a class for TestSuites.

public class TestSuite_Google 
{	
	private boolean isExecuted=false;
	
	private boolean isFail=false;	
	private String initialFailTime = "Inf.";
	private Timestamp last_failTime;
	
	private int TsId;
	private Timestamp last_launchTime;
	private String last_stage;
	private String last_status;
	private long last_executionTime;	
	

	//for initialization
	public TestSuite_Google(int tsId) {
		super();
		TsId = tsId;
	}

	//if each Ts is executed, the related record will be updated
	public TestSuite_Google(int TsId, Timestamp last_launchTime,String last_stage, String last_status, long last_executionTime) 
	{
		super();
		
		this.TsId = TsId;
		this.last_launchTime = last_launchTime;
		this.last_stage = last_stage;
		this.last_status = last_status;
		this.last_executionTime = last_executionTime;
					
		//if the Ts has not been detected a failure, then it has no last_fail record and boolean isFail is still false.
		if(last_status.equals("FAILED"))
		{
			this.last_failTime = last_launchTime;
			this.isFail =true;
		}
	}
		
	public Timestamp getLast_failTime() {
		return last_failTime;
	}

	public void setLast_failTime(Timestamp last_failTime)
	{
		this.last_failTime = last_failTime;
		this.isFail = true; // also update this.isFail
		this.last_status ="FAILED";
	}
	
	public String getInitialFailTime() {
		return initialFailTime;
	}

	public void setInitialFailTime(String initialFailTime) 
	{
		this.initialFailTime = initialFailTime;
	}
	
	public int getTsId() {
		return TsId;
	}
	public void setTsId(int tsId) {
		TsId = tsId;
	}
	public Timestamp getLast_launchTime() {
		return last_launchTime;
	}

	public void setLast_launchTime(Timestamp last_launchTime) {
		this.last_launchTime = last_launchTime;
	}

	public String getLast_stage() {
		return last_stage;
	}

	public void setLast_stage(String last_stage) {
		this.last_stage = last_stage;
	}

	public String getLast_status() {
		return last_status;
	}

	public void setLast_status(String last_status) {
		this.last_status = last_status;
	}

	public long getLast_executionTime() {
		return last_executionTime;
	}

	public void setLast_executionTime(long last_executionTime) {
		this.last_executionTime = last_executionTime;
	}

	public boolean isExecuted() {
		return isExecuted;
	}

	public void setExecuted(boolean isExecuted) {
		this.isExecuted = isExecuted;
	}

	public boolean isFail() {
		return isFail;
	}

	public void setFail(boolean isFail) {
		this.isFail = isFail;
	}
	
	
}
