package parsingCommandLine;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

@SuppressWarnings("deprecation")
public class Cli 
{
	private String[] args = null;
	private Options options = new Options();
	
	public Cli(String[] args)
	{
		this.args = args;
		
		//-h or --help is used to show a list of options
		this.options.addOption("h", "help", false, "show help");
		
		this.options.addOption("A", "choiceForDataset", true, "set the dataset as 'googleDataset' or 'travisDataset' ");
		this.options.addOption("e", "alwaySelectedStage", true, "set the stage('pres' or 'post' or '') in which the tests will always execute.");
		this.options.addOption("a", "failureWindow", true, "set the failureWindow(integers)");
		this.options.addOption("b", "executionWindow", true, "set the executionWindow(integers)");
		this.options.addOption("c", "failmmhh", true, "set the minutes or hours for failure window('minutes' or 'hours')");
		this.options.addOption("d", "executemmhh", true, "set the minutes or hours for execution window('minutes' or 'hours')");
		this.options.addOption("s", "selectedStage", true, "set the selected stage('pres' or 'post' or 'pres and post')");		
		this.options.addOption("x", "repetitiveWindow", true, "set the repetitiveWindow(integers)");
		this.options.addOption("y", "repetitivemmhh", true, "set the minutes or hours for repetitive window('minutes' or 'hours')");
		this.options.addOption("B", "base", true, "set the base number for decay rate");
		this.options.addOption("H", "life", true, "set the life number for decay rate");
		this.options.addOption("C", "comparedNumber", true, "set the compared number for dacay rate");
		this.options.addOption("t", "coefficient", true, "set coefficient for d2");
		this.options.addOption("i", "intra_commit option", true, "if intra_commit prioritization is needed, set 'true'; else set 'false'");
		
		
	}
	
	private void help()
	{
		HelpFormatter formater = new HelpFormatter();
//		formater.printHelp("Main", options);
		System.exit(0);
	}
	
	public void parse()
	{
		CommandLineParser parser = new DefaultParser();
		CommandLine cmd = null;
		try 
		{
			cmd = parser.parse(options, args);
			
			if(cmd.hasOption("h"))
				help();
			
			if(cmd.hasOption("A"))
			{
				args[0] = cmd.getOptionValue("A");
			}
					
			if(cmd.hasOption("a"))
			{
				args[1] = cmd.getOptionValue("a");
			}
			
			if(cmd.hasOption("b"))
			{
				args[2] = cmd.getOptionValue("b");
			}
			
			if(cmd.hasOption("c"))
			{
				args[3] = cmd.getOptionValue("c");
			}
			
			if(cmd.hasOption("d"))
			{
				args[4] = cmd.getOptionValue("d");
			}		
			if(cmd.hasOption("x"))
			{
				args[5] = cmd.getOptionValue("x");
			}
			if(cmd.hasOption("y"))
			{
				args[6] = cmd.getOptionValue("y");
			}
			
			if(cmd.hasOption("e"))
			{
				args[7] = cmd.getOptionValue("e");
			}
			if(cmd.hasOption("s"))
			{
				args[8] = cmd.getOptionValue("s");
			}
			
			if(cmd.hasOption("B"))
			{
				args[9] = cmd.getOptionValue("B");
			}
			
			if(cmd.hasOption("H"))
			{
				args[10] = cmd.getOptionValue("H");
			}
			if(cmd.hasOption("C"))
			{
				args[11] = cmd.getOptionValue("C");
			}
			if(cmd.hasOption("t"))
			{
				args[12] = cmd.getOptionValue("t");
			}
			
			if(cmd.hasOption("i"))
			{
				args[13] = cmd.getOptionValue("i");
			}
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	public String[] getArgs() {
		return args;
	}

	public void setArgs(String[] args) {
		this.args = args;
	}
}
