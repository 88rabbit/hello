package exeRecord;

import java.sql.Timestamp;

import testSuites.TestSuite_Google;

public class ExeRecord_Google 
{
	//add previousIsFail
	private boolean[] previousIsFail;
	private int[] Ts_recordNum; // to record the execution times of a certain Ts
	private double[] Ts_failureNum; //to record the executed failure time of a certain Ts
	
	private boolean[] isExecuted;
	private boolean[] isFail ;
	
	private int[] tsId;
	private String[] stage;
	private String[] status;
	private Timestamp[] last_launchTime;
	private  Timestamp[] last_failTime;
	
	private int[] countNotExecuted;
	private double[] Ck_p;
	private double[] Ck_s;
	private double[] Ck_f;
	
	//add is transitioned to pass
	private boolean[] isTransitionedToPass;
	
	
	private int[] consecutiveExe;
	private int[] consecutiveSkip;
	private int[] consecutiveFail;
	private int[] consecutivePass;
	
	
	private int distinctTsNum;
	
//	private double inc;
//	private int x=0;
	
	public void initializeRecord(int distinctTsNum, double inc)
	{
		this.distinctTsNum = distinctTsNum;
		Ts_recordNum = new int[distinctTsNum];
		Ts_failureNum = new double[distinctTsNum];
		previousIsFail = new boolean[distinctTsNum];
		//for transitionToPass
		isTransitionedToPass = new boolean[distinctTsNum];
		
		isExecuted = new boolean[distinctTsNum];
		isFail = new boolean[distinctTsNum];
		tsId = new int[distinctTsNum];
		stage= new String[distinctTsNum];
		status=new String[distinctTsNum];
		last_launchTime = new  Timestamp[distinctTsNum];
		last_failTime = new  Timestamp[distinctTsNum];
		
		Ck_p = new double[distinctTsNum]; //pass
		Ck_s = new double[distinctTsNum]; //skip
		Ck_f = new double[distinctTsNum]; //fail
		
		
		countNotExecuted = new int[distinctTsNum];// for recording the times of not being executed
		
		consecutiveExe = new int[distinctTsNum];
		consecutiveSkip = new int[distinctTsNum];
		consecutiveFail = new int[distinctTsNum];
		consecutivePass =new int[distinctTsNum];
		
		for(int i=1; i<distinctTsNum; i++)
		{	
			Ts_recordNum[i] =0;
			Ts_failureNum[i] =0;
			previousIsFail[i] = false;
			
			isExecuted[i] = false;
			isFail[i] = false;
			
			//add transitionToPass
			isTransitionedToPass[i] = false;
			
			tsId[i]=i;
			stage[i] = "N";
			status[i] = "N";	
			
			/*
			 * when initialized, set them as 0
			 */
			Ck_p[i]=0;
			Ck_s[i]=0;
			Ck_f[i]=0;
			
			countNotExecuted[i]=0;// for recording the times of not being executed
			
			consecutiveExe[i] =0;
			consecutiveSkip[i] =0;
			consecutiveFail[i]=0;
			consecutivePass[i]=0;
			
		}
	}
		
	public void updateTsRecord(TestSuite_Google ts, double coeff_f, double coeff_e, double coeff_s)
	{
//		System.out.println("CK"+Ck[ts.getTsId()]);	
		
//		
		if(this.Ts_recordNum[ts.getTsId()]>=1)
		{
			this.previousIsFail[ts.getTsId()] = this.isFail[ts.getTsId()];
		}
		
		this.Ts_recordNum[ts.getTsId()]++;
		
		this.isExecuted[ts.getTsId()] = true;
		
		this.stage[ts.getTsId()] = ts.getLast_stage();
		this.status[ts.getTsId()] = ts.getLast_status();
		this.last_launchTime[ts.getTsId()] =ts.getLast_launchTime();		
		
		
		double ce = consecutiveExe[ts.getTsId()];
		double de = -(double)ce*(double)(1/coeff_e);
		Ck_f[ts.getTsId()] = Math.max(0, Ck_f[ts.getTsId()]+de);
				
		Ck_s[ts.getTsId()] = 0;
		//if it fails
		if(ts.isFail()==true)
		{
			this.isTransitionedToPass[ts.getTsId()] = false;
			this.last_failTime[ts.getTsId()] = ts.getLast_failTime();
			this.isFail[ts.getTsId()] = true;
			Ts_failureNum[ts.getTsId()]++;// for recording the times of not being executed
					
			consecutiveFail[ts.getTsId()]++;
			double cf = consecutiveFail[ts.getTsId()];
			double df=1-(double)(1/coeff_f)*cf;

			Ck_f[ts.getTsId()]= Math.min(1, Ck_f[ts.getTsId()]+df); //fail
			
			
			//then reset ck_s and ck_p
//			consecutivePass[ts.getTsId()]=0;		
//			Ck_p[ts.getTsId()] = 0;
//			Ck_p[ts.getTsId()] = Math.min(1, Ck_p[ts.getTsId()]+(double)(1-d4));	
//			System.out.println("D3:" +coefficient2+":"+consecutiveFail[ts.getTsId()]+":"+h3+":"+d3);
//			System.out.println((double)d3);
//			
//			if(ts.getTsId()==102)
//			{
//				System.out.println(2); //reperesent fail
//			}
//			System.out.println("CK_f"+Ck_f[ts.getTsId()]);		
		}
		else
		{
			//if it pass
			this.isTransitionedToPass[ts.getTsId()] = true;
			
			consecutivePass[ts.getTsId()]++;
//			double cp = consecutivePass[ts.getTsId()];
//			double d1= -((double)cp*(double)(1/coeff1));
			
//			if(cp==1)
//			{
//				Ck_p[ts.getTsId()] =1;
//			}
			
//			Ck_p[ts.getTsId()] = Math.max(0,Ck_p[ts.getTsId()]+d1);	
			
			//reset
			consecutiveFail[ts.getTsId()]=0;
//			Ck_f[ts.getTsId()] = 0;
//			Ck_f[ts.getTsId()] = Math.max(0, Ck_f[ts.getTsId()]-d4);
			
			
//			System.out.println(d1);
//			if(ts.getTsId()==102)
//			{
//				System.out.println(1); //reperesent pass
//			}
			
			//no change Ck[ts.getTsId()]
			
//			System.out.println("CK_p"+Ck_p[ts.getTsId()]);		
			
		}
	}
	
	//if it skips
	public void updateGrow(TestSuite_Google ts, double coeff_f, double coeff_e, double coeff_s)
	{			
		double cs = consecutiveSkip[ts.getTsId()];
				
		double ds = (double)(1/coeff_s)*cs;
		
		Ck_s[ts.getTsId()] = Math.min(1,Ck_s[ts.getTsId()]+ds);
		
		
//		double d1= (double)(1/(coeff3*cs));
//		
//		Ck_f[ts.getTsId()] = Math.max(0, Ck_f[ts.getTsId()]-d1);
//		
		//reset
//		Ck_f[ts.getTsId()] = 0;
//		Ck_p[ts.getTsId()] = 0;
		
		//reset
		consecutivePass[ts.getTsId()]=0;
		consecutiveFail[ts.getTsId()]=0;
		
//		System.out.println(d2);
//		if(ts.getTsId()==102)
//		{
//			System.out.println(0); //reperesent pass
//		}
		
//		System.out.println("CK_s"+Ck_s[ts.getTsId()]);	
	
	}
	
	public int countDistinctFails()
	{
		int numOfDistinctFails=0;
		for(int i=0;i<distinctTsNum; i++)
		{
			if(isFail[i])
			{
				numOfDistinctFails++;
			}
		}
		return numOfDistinctFails;
	}
//	
	public boolean[] getIsExecuted() {
		return isExecuted;
	}
	
	public boolean[] getIsFail() {
		return isFail;
	}

	public int[] getTsId() {
		return tsId;
	}
	
	public String[] getStage() {
		return stage;
	}

	public String[] getStatus() {
		return status;
	}

	public Timestamp[] getLast_launchTime() {
		return last_launchTime;
	}

	public Timestamp[] getLast_failTime() {
		return last_failTime;
	}

	public boolean[] getIsTransitionedToPass() {
		return isTransitionedToPass;
	}

	public void setIsTransitionedToPass(boolean[] isTransitionedToPass) {
		this.isTransitionedToPass = isTransitionedToPass;
	}

	public boolean[] getPreviousIsFail() {
		return previousIsFail;
	}

	public void setPreviousIsFail(boolean[] previousIsFail) {
		this.previousIsFail = previousIsFail;
	}

	public int[] getTs_recordNum() {
		return Ts_recordNum;
	}

	public void setTs_recordNum(int[] ts_recordNum) {
		Ts_recordNum = ts_recordNum;
	}

	public double[] getTs_failureNum() {
		return Ts_failureNum;
	}

	public void setTs_failureNum(double[] ts_failureNum) {
		Ts_failureNum = ts_failureNum;
	}

	public int[] getCountNotExecuted() {
		return countNotExecuted;
	}

	public int[] getConsecutiveExe() {
		return consecutiveExe;
	}

	public void setConsecutiveExe(int i, int consecutiveExe) {
		this.consecutiveExe[i] = consecutiveExe;
	}

	public int[] getConsecutiveSkip() {
		return consecutiveSkip;
	}

	public void setConsecutiveSkip(int i, int consecutiveSkip) {
		this.consecutiveSkip[i] = consecutiveSkip;
	}

	public int[] getConsecutivePass() {
		return consecutivePass;
	}

	public void setConsecutivePass(int i, int consecutivePass) {
		this.consecutivePass[i] = consecutivePass;
	}

	public double[] getCk_p() {
		return Ck_p;
	}

	public void setCk_p(double[] ck_p) {
		Ck_p = ck_p;
	}

	public double[] getCk_s() {
		return Ck_s;
	}

	public void setCk_s(double[] ck_s) {
		Ck_s = ck_s;
	}

	public double[] getCk_f() {
		return Ck_f;
	}

	public void setCk_f(double[] ck_f) {
		Ck_f = ck_f;
	}

	
	
	
	
}
