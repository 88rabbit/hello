package exeRecord;

import testSuites.TestSuite_Travis;

public class ExeRecord_Travis 
{
	//for decay
	private int[] Ts_recordNum; // to record the execution times of a certain Ts
	private double[] Ts_failureNum; //to record the executed failure time of a certain Ts
	
	
	private boolean[] isExecuted;
	private boolean[] isFail_Ts ;
//	private boolean[] isError_Ts;
	
//	private Timestamp[] Ts_failTime; //Ts_start_time
	private String[] Ts_state;
	
	private int[] TsId;
	private double[] Ts_duration;	 //Ts execution time
//	private int[] Ts_runs;
//	private int[] Ts_assertions;
	private int[] Ts_failures;
//	private int[] Ts_errors;
//	private int[] Ts_skips;
	
	private int[] Build_number;
//	private String[] Build_state;
//	private Timestamp[] Build_start_time;
//	private Timestamp[] Build_finish_time;
//	private double[] Build_duration;
	
//	private int[] Job_id;
//	private String[] Job_state;
//	private Timestamp[] Job_start_time;
//	private int[] Job_allow_failure;

	private String[] Commit_sha;	
		
	private int distinctTsNum;
		
	private double[] commitsSinceLastExe;
	private double[] commitsSinceLastFail;
		
//	private Timestamp[] Job_finish_time;
//	private double[] Job_duration;	
//	private int[] Repository_id;
//	private int[] Commit_id;
//	private String[] Commit_short_sha;
		
	public void initializeRecord(int distinctTsNum)
	{
		this.distinctTsNum = distinctTsNum;
		
		//for deca
		Ts_recordNum = new int[distinctTsNum];
		Ts_failureNum = new double[distinctTsNum];
		
		
		isExecuted = new boolean[distinctTsNum];
		isFail_Ts = new boolean[distinctTsNum] ;
//		isError_Ts = new boolean[distinctTsNum];
		
//		Ts_failTime = new Timestamp[distinctTsNum]; //Ts_start_time
		Ts_state = new String[distinctTsNum];
		
		TsId = new int[distinctTsNum];
		Ts_duration = new double[distinctTsNum];	 //Ts execution time
//		Ts_runs = new int[distinctTsNum];
//		Ts_assertions=new int[distinctTsNum];
		Ts_failures = new int[distinctTsNum];
//		Ts_errors = new int[distinctTsNum];
//		Ts_skips = new int[distinctTsNum];
//		Ts_start_time = new Timestamp[distinctTsNum]; //Ts launch time
		
		Build_number = new int[distinctTsNum];
//		Build_state = new String[distinctTsNum];
//		Build_start_time = new Timestamp[distinctTsNum];
//		Build_finish_time = new Timestamp[distinctTsNum];
//		Build_duration = new double[distinctTsNum];
		
//		Job_id = new int[distinctTsNum];
//		Job_start_time = new Timestamp[distinctTsNum];
		Commit_sha = new String[distinctTsNum];
		
	
		commitsSinceLastExe = new double[distinctTsNum];
		commitsSinceLastFail = new double[distinctTsNum];
		
		for(int i=1; i<distinctTsNum; i++)
		{	
//			System.out.println(i);
			TsId[i] = i;	
			isExecuted[i] = false;			
			isFail_Ts[i] = false ;
//			isError_Ts[i] = false;			
			Ts_state[i] = "N";			
			
			
			Ts_recordNum[i] =0;
			Ts_failureNum[i] =0;
			
			commitsSinceLastExe[i] = 0;
			commitsSinceLastFail[i] = 0;
			
		}
	}
		
	public void updateTsRecord(TestSuite_Travis ts, int numOfCommit)
	{
		this.Ts_recordNum[ts.getTsId()]++;
		
		this.isExecuted[ts.getTsId()] = true;
		
		this.Ts_state[ts.getTsId()] = ts.getTs_state();
		
		this.Ts_duration[ts.getTsId()] = ts.getTs_duration();	 //Ts execution time
//		this.Ts_runs[ts.getTsId()]= ts.getTs_runs();
//		this.Ts_assertions[ts.getTsId()]=ts.getTs_assertions();
		this.Ts_failures[ts.getTsId()] = ts.getTs_failures();
//		this.Ts_errors[ts.getTsId()] = ts.getTs_errors();
//		this.Ts_skips[ts.getTsId()] = ts.getTs_skips();
//		this.Ts_start_time[ts.getTsId()] = ts.getTs_start_time(); //Ts launch time
		
		commitsSinceLastExe[ts.getTsId()] = numOfCommit;
		
		
		//update isFail_Ts 
		if(ts.isFail_Ts()==true )
		{					
//			this.Ts_failTime[ts.getTsId()] = ts.getTs_failTime();
			
			this.isFail_Ts[ts.getTsId()] = true;
			Ts_failureNum[ts.getTsId()]++;

			commitsSinceLastFail[ts.getTsId()] = numOfCommit;
		}
		this.Build_number[ts.getTsId()] = ts.getBuild_number();
		this.Commit_sha[ts.getTsId()] = ts.getCommit_sha();
		
//		this.Build_id[ts.getTsId()] = ts.getBuild_id();
		
//		this.Build_state[ts.getTsId()] = ts.getBuild_state();
//		this.Build_start_time[ts.getTsId()] = ts.getBuild_start_time();
//		this.Build_finish_time[ts.getTsId()] = ts.getBuild_finish_time();
//		this.Build_duration[ts.getTsId()] = ts.getBuild_duration();
//		
//		this.Job_id[ts.getTsId()] = ts.getJob_id();
//		this.Job_number[ts.getTsId()] = ts.getJob_number();
//		this.Job_state[ts.getTsId()] = ts.getJob_state();
//		this.Job_start_time[ts.getTsId()] = ts.getJob_start_time();
//		this.Job_finish_time[ts.getTsId()] = ts.getJob_finish_time();
//		this.Job_duration[ts.getTsId()] = ts.getJob_duration();
//		
//		this.Repository_id[ts.getTsId()] = ts.getRepository_id();
//		this.Commit_id[ts.getTsId()] = ts.getCommit_id();		
//		this.Commit_short_sha[ts.getTsId()] = ts.getCommit_short_sha();
			
	}
	
	
	
	
	public int countDistinctFails()
	{
		int numOfDistinctFails=0;
		for(int i=0;i<distinctTsNum; i++)
		{
			if(isFail_Ts[i])
			{
				numOfDistinctFails++;
			}
		}
		return numOfDistinctFails;
	}
	

	public boolean[] getIsExecuted() {
		return isExecuted;
	}

	public void setIsExecuted(boolean[] isExecuted) {
		this.isExecuted = isExecuted;
	}

	public boolean[] getIsFail_Ts() {
		return isFail_Ts;
	}

	public void setIsFail_Ts(boolean[] isFail_Ts) {
		this.isFail_Ts = isFail_Ts;
	}

	public String[] getTs_state() {
		return Ts_state;
	}

	public void setTs_state(String[] ts_state) {
		Ts_state = ts_state;
	}

	public int[] getTsId() {
		return TsId;
	}

	public void setTsId(int[] tsId) {
		TsId = tsId;
	}

	public double[] getTs_duration() {
		return Ts_duration;
	}

	public void setTs_duration(double[] ts_duration) {
		Ts_duration = ts_duration;
	}

	public int[] getTs_failures() {
		return Ts_failures;
	}

	public void setTs_failures(int[] ts_failures) {
		Ts_failures = ts_failures;
	}


	public int[] getBuild_number() {
		return Build_number;
	}

	public void setBuild_number(int[] build_number) {
		Build_number = build_number;
	}

	
	public int[] getTs_recordNum() {
		return Ts_recordNum;
	}

	public void setTs_recordNum(int[] ts_recordNum) {
		Ts_recordNum = ts_recordNum;
	}

	
	public double[] getTs_failureNum() {
		return Ts_failureNum;
	}

	public void setTs_failureNum(double[] ts_failureNum) {
		Ts_failureNum = ts_failureNum;
	}

	public double[] getCommitsSinceLastExe() {
		return commitsSinceLastExe;
	}

	public void setCommitsSinceLastExe(double[] commitsSinceLastExe) {
		this.commitsSinceLastExe = commitsSinceLastExe;
	}

	public double[] getCommitsSinceLastFail() {
		return commitsSinceLastFail;
	}

	public void setCommitsSinceLastFail(double[] commitsSinceLastFail) {
		this.commitsSinceLastFail = commitsSinceLastFail;
	}

	

}
