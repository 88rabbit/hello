#!/bin/bash

libDir=../lib
srcDir=../src
binDir=../bin


inputParameter_1=96   #faiCommitWindow
inputParameter_2=1	  #exeCommitWindow
inputParameter_3=hours	#failmmhh
inputParameter_4=hours # exemmhh
inputParameter_7=1 #repetitiveWindow
inputParameter_8=hours #repetitivemmhh

inputParameter_5=post	
inputParameter_6=post   #selected stage

inputParameter_9=8       # 
inputParameter_10=800	   # 

inputParameter_11=3     #  rate coefficient x 
inputParameter_12=2    #numOfProcessor

inputParameter_13=false  

# for inputParameter_11 in 0.01 0.025 0.05 0.075
for inputParameter_11 in 1
# for inputParameter_11 in 0.25 0.5 0.75 1
do
	for inputParameter_12 in 1
	# for inputParameter_12 in 2 4 8
	do
			# for inputParameter_10 in 50 100 200 500 1000
			for inputParameter_2 in 500
			do
				#coeff1
				# for inputParameter_9 in 50 100 200 500 1000
				for inputParameter_1 in 500
				# for inputParameter_9 in 256
				do
			#compile the program
			javac -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar $srcDir/Main.java

			# with option -h, the list of options will show up
			java -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -h

			#run the program with parameters
			java -Xmx4g -cp $binDir:$libDir/commons-cli-1.3.1.jar:$libDir/mysql-connector-java-5.0.8-bin.jar:$libDir/hamcrest-core-1.3.jar Main -A=travisDataset -a=$inputParameter_1 -b=$inputParameter_2 -c=$inputParameter_3 -d=$inputParameter_4 -e=$inputParameter_5 -s=$inputParameter_6 -x=$inputParameter_7 -y=$inputParameter_8 -B=$inputParameter_9 -H=$inputParameter_10 -C=$inputParameter_11 -t=$inputParameter_12 -i=$inputParameter_13

	        done 
		done
	done
done



